import React from 'react';
import { useAuth } from './hooks/useAuth';
import { Auth } from './components/Auth';
import { Feed } from './components/Feed';

function App() {
  const { user, loading, signIn, signUp, signOut } = useAuth();

  console.log('App render:', { user: !!user, loading });

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-600 to-blue-600 flex items-center justify-center">
        <div className="text-white text-xl font-medium">Loading SocialFlow...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <Auth
        onSignIn={signIn}
        onSignUp={signUp}
        loading={loading}
      />
    );
  }

  return <Feed user={user} onSignOut={signOut} />;
}

export default App;