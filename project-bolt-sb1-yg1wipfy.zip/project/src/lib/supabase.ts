import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://ojkpunxqwvmznrwsljvg.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

console.log('Supabase Environment Check:', {
  MODE: import.meta.env.MODE,
  hasKey: !!supabaseAnonKey,
  keyLength: supabaseAnonKey?.length || 0,
  keyPreview: supabaseAnonKey ? `${supabaseAnonKey.substring(0, 20)}...` : 'No key found'
});

// If you see "No key found" in the browser console,
// add VITE_SUPABASE_ANON_KEY in Bolt → Environment and republish.
if (!supabaseAnonKey) {
  throw new Error('Missing VITE_SUPABASE_ANON_KEY in your Bolt environment.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  realtime: { params: { eventsPerSecond: 10 } },
  auth: { persistSession: true, autoRefreshToken: true },
});
