import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { User } from '@supabase/supabase-js';

interface Reaction {
  id: string;
  post_id: string;
  user_id: string;
  reaction: string;
  created_at: string;
}

export function useReactions(postId: string, user: User | null) {
  const [reactions, setReactions] = useState<Reaction[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!postId || !user) {
      setReactions([]);
      return;
    }

    fetchReactions();
    subscribeToReactions();
  }, [postId, user]);

  const fetchReactions = async () => {
    if (!postId || !user) return;

    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('post_reactions')
        .select('*')
        .eq('post_id', postId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      setReactions(data || []);
    } catch (error) {
      console.error('Error fetching reactions:', error);
    } finally {
      setLoading(false);
    }
  };

  const subscribeToReactions = () => {
    if (!postId || !user) return () => {};

    const subscription = supabase
      .channel(`post-reactions-${postId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'post_reactions',
          filter: `post_id=eq.${postId}`,
        },
        (payload) => {
          console.log('Reaction change:', payload);
          fetchReactions();
        }
      )
      .subscribe();

    return () => subscription.unsubscribe();
  };

  const addReaction = async (emoji: string) => {
    if (!user || !postId) return { error: new Error('User not authenticated') };

    try {
      const { data, error } = await supabase
        .from('post_reactions')
        .insert({
          post_id: postId,
          user_id: user.id,
          reaction: emoji,
        })
        .select()
        .single();

      if (error) throw error;
      
      return { data, error: null };
    } catch (error) {
      console.error('Error adding reaction:', error);
      return { data: null, error: error as Error };
    }
  };

  const removeReaction = async (reactionId: string) => {
    if (!user) return { error: new Error('User not authenticated') };

    try {
      const { error } = await supabase
        .from('post_reactions')
        .delete()
        .eq('id', reactionId)
        .eq('user_id', user.id);

      if (error) throw error;
      
      return { error: null };
    } catch (error) {
      console.error('Error removing reaction:', error);
      return { error: error as Error };
    }
  };

  return {
    reactions,
    loading,
    addReaction,
    removeReaction,
  };
}