import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { User } from '@supabase/supabase-js';

interface FriendRequest {
  id: string;
  sender_id: string;
  receiver_id: string;
  status: 'pending' | 'accepted' | 'rejected';
  created_at: string;
  updated_at: string;
  sender_profile?: {
    id: string;
    username: string;
    full_name: string;
    avatar_url?: string;
  };
  receiver_profile?: {
    id: string;
    username: string;
    full_name: string;
    avatar_url?: string;
  };
}

interface Friend {
  id: string;
  username: string;
  full_name: string;
  avatar_url?: string;
}

export function useSocial(user: User | null) {
  const [pendingRequests, setPendingRequests] = useState<FriendRequest[]>([]);
  const [sentRequests, setSentRequests] = useState<FriendRequest[]>([]);
  const [friends, setFriends] = useState<Friend[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setPendingRequests([]);
      setSentRequests([]);
      setFriends([]);
      setLoading(false);
      return;
    }

    fetchFriendRequests();
    fetchFriends();
    subscribeToChanges();
  }, [user]);

  const fetchFriendRequests = async () => {
    if (!user) return;

    try {
      console.log('Fetching friend requests for user:', user.id);
      
      // Fetch pending requests (received)
      const { data: pendingData, error: pendingError } = await supabase
        .from('friend_requests')
        .select(`
          *,
          sender_profile:profiles!friend_requests_sender_id_fkey(
            id, username, full_name, avatar_url
          )
        `)
        .eq('receiver_id', user.id)
        .eq('status', 'pending');

      if (pendingError) throw pendingError;

      // Fetch sent requests
      const { data: sentData, error: sentError } = await supabase
        .from('friend_requests')
        .select(`
          *,
          receiver_profile:profiles!friend_requests_receiver_id_fkey(
            id, username, full_name, avatar_url
          )
        `)
        .eq('sender_id', user.id)
        .eq('status', 'pending');

      if (sentError) throw sentError;

      console.log('Friend requests fetched:', { pending: pendingData?.length, sent: sentData?.length });
      setPendingRequests(pendingData || []);
      setSentRequests(sentData || []);
    } catch (error) {
      console.error('Error fetching friend requests:', error);
    }
  };

  const fetchFriends = async () => {
    if (!user) return;

    try {
      console.log('Fetching friends for user:', user.id);
      
      // Get accepted friend requests where user is either sender or receiver
      const { data: friendRequestsData, error } = await supabase
        .from('friend_requests')
        .select(`
          sender_id,
          receiver_id,
          sender_profile:profiles!friend_requests_sender_id_fkey(
            id, username, full_name, avatar_url
          ),
          receiver_profile:profiles!friend_requests_receiver_id_fkey(
            id, username, full_name, avatar_url
          )
        `)
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
        .eq('status', 'accepted');

      if (error) throw error;

      // Extract friends (the other person in each friendship)
      const friendsList: Friend[] = [];
      friendRequestsData?.forEach(request => {
        if (request.sender_id === user.id && request.receiver_profile) {
          friendsList.push(request.receiver_profile);
        } else if (request.receiver_id === user.id && request.sender_profile) {
          friendsList.push(request.sender_profile);
        }
      });

      console.log('Friends fetched:', friendsList.length);
      setFriends(friendsList);
    } catch (error) {
      console.error('Error fetching friends:', error);
    } finally {
      setLoading(false);
    }
  };

  const subscribeToChanges = () => {
    if (!user) return () => {};

    console.log('Setting up friend requests subscription');
    const subscription = supabase
      .channel(`friend-requests-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'friend_requests',
          filter: `or(sender_id.eq.${user.id},receiver_id.eq.${user.id})`,
        },
        (payload) => {
          console.log('Friend request change:', payload);
          fetchFriendRequests();
          fetchFriends();
        }
      )
      .subscribe();

    return () => subscription.unsubscribe();
  };

  const searchUsers = async (query: string) => {
    if (!user || !query.trim()) return [];

    try {
      console.log('Searching users:', query);
      const { data, error } = await supabase
        .from('profiles')
        .select('id, username, full_name, avatar_url')
        .or(`username.ilike.%${query}%,full_name.ilike.%${query}%`)
        .neq('id', user.id)
        .limit(10);

      if (error) throw error;
      
      console.log('Search results:', data?.length);
      return data || [];
    } catch (error) {
      console.error('Error searching users:', error);
      return [];
    }
  };

  const sendFriendRequest = async (receiverId: string) => {
    if (!user) return { error: new Error('User not authenticated') };

    try {
      console.log('Sending friend request to:', receiverId);
      const { data, error } = await supabase
        .from('friend_requests')
        .insert({
          sender_id: user.id,
          receiver_id: receiverId,
          status: 'pending'
        })
        .select()
        .single();

      if (error) throw error;
      
      console.log('Friend request sent:', data);
      await fetchFriendRequests();
      return { data, error: null };
    } catch (error) {
      console.error('Error sending friend request:', error);
      return { data: null, error: error as Error };
    }
  };

  const respondToFriendRequest = async (requestId: string, response: 'accepted' | 'rejected') => {
    if (!user) return { error: new Error('User not authenticated') };

    try {
      console.log('Responding to friend request:', requestId, response);
      const { data, error } = await supabase
        .from('friend_requests')
        .update({ 
          status: response,
          updated_at: new Date().toISOString()
        })
        .eq('id', requestId)
        .eq('receiver_id', user.id)
        .select()
        .single();

      if (error) throw error;
      
      console.log('Friend request response:', data);
      await fetchFriendRequests();
      await fetchFriends();
      return { data, error: null };
    } catch (error) {
      console.error('Error responding to friend request:', error);
      return { data: null, error: error as Error };
    }
  };

  const cancelFriendRequest = async (requestId: string) => {
    if (!user) return { error: new Error('User not authenticated') };

    try {
      console.log('Cancelling friend request:', requestId);
      const { error } = await supabase
        .from('friend_requests')
        .delete()
        .eq('id', requestId)
        .eq('sender_id', user.id);

      if (error) throw error;
      
      console.log('Friend request cancelled');
      await fetchFriendRequests();
      return { error: null };
    } catch (error) {
      console.error('Error cancelling friend request:', error);
      return { error: error as Error };
    }
  };

  const getPendingRequests = () => pendingRequests;
  const getSentRequests = () => sentRequests;
  const getFriends = () => friends;

  return {
    loading,
    searchUsers,
    sendFriendRequest,
    respondToFriendRequest,
    cancelFriendRequest,
    getPendingRequests,
    getSentRequests,
    getFriends,
    refetch: () => {
      fetchFriendRequests();
      fetchFriends();
    }
  };
}