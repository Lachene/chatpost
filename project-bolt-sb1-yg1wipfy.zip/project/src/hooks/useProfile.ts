import { useState, useEffect } from 'react';
import { supabase, Profile } from '../lib/supabase';
import { User } from '@supabase/supabase-js';

export function useProfile(user: User | null) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setProfile(null);
      setLoading(false);
      return;
    }

    fetchProfile();
  }, [user]);

  const fetchProfile = async () => {
    if (!user) return;

    console.log('Fetching profile for user:', user.id);
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();

      console.log('Profile query result:', { data, error });
      
      if (error && error.code !== 'PGRST116') {
        throw error;
      }
      
      if (!data) {
        console.log('No profile found, creating one...');
        // Try to create a profile if it doesn't exist with better error handling
        let username = user.user_metadata?.username || `user_${user.id.substring(0, 8)}`;
        
        // Clean username
        username = username.toLowerCase().replace(/[^a-z0-9_]/g, '');
        if (!username) {
          username = `user_${user.id.substring(0, 8)}`;
        }
        
        const fullName = user.user_metadata?.full_name || '';
        
        // Try creating profile with retry logic
        let attempts = 0;
        const maxAttempts = 3;
        let profileCreated = false;
        
        while (attempts < maxAttempts && !profileCreated) {
          const attemptUsername = attempts === 0 ? username : `${username}_${attempts}`;
          
          const { data: newProfile, error: createError } = await supabase
            .from('profiles')
            .insert({
              id: user.id,
              username: attemptUsername,
              full_name: fullName,
              followers_count: 0,
              following_count: 0,
              posts_count: 0,
              friends_count: 0,
            })
            .select()
            .single();
            
          if (!createError) {
            console.log('Profile created successfully:', newProfile);
            setProfile(newProfile);
            profileCreated = true;
          } else if (createError.code === '23505' && attempts < maxAttempts - 1) {
            // Unique constraint violation, try again with different username
            console.log(`Username ${attemptUsername} taken, trying again...`);
            attempts++;
          } else if (attempts === maxAttempts - 1) {
            // Last attempt with timestamp
            const timestampUsername = `user_${user.id.substring(0, 8)}_${Date.now()}`;
            const { data: finalProfile, error: finalError } = await supabase
              .from('profiles')
              .insert({
                id: user.id,
                username: timestampUsername,
                full_name: fullName,
                followers_count: 0,
                following_count: 0,
                posts_count: 0,
                friends_count: 0,
              })
              .select()
              .single();
              
            if (!finalError) {
              console.log('Profile created with timestamp username:', finalProfile);
              setProfile(finalProfile);
              profileCreated = true;
            } else {
              console.error('Final attempt to create profile failed:', finalError);
              throw finalError;
            }
          } else {
            console.error('Error creating profile:', createError);
            throw createError;
          }
        }
      } else {
        setProfile(data);
      }
    } catch (err) {
      console.error('Error fetching profile:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch profile');
    } finally {
      setLoading(false);
    }
  };

  const updateProfile = async (updates: Partial<Profile>) => {
    if (!user) return { error: new Error('User not authenticated') };

    try {
      const { data, error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id)
        .select()
        .single();

      if (error) throw error;
      setProfile(data);
      return { data, error: null };
    } catch (err) {
      return { data: null, error: err as Error };
    }
  };

  return {
    profile,
    loading,
    error,
    updateProfile,
    refetch: fetchProfile,
  };
}