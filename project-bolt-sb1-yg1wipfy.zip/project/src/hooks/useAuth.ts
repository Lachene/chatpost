import { useState, useEffect } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    console.log('useAuth: Setting up auth listener');
    
    // Get initial session
    supabase.auth.getSession().then(({ data: { session }, error }) => {
      console.log('Initial session:', { session: !!session, error });
      setUser(session?.user ?? null);
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        console.log('Auth state change:', event, { session: !!session });
        setUser(session?.user ?? null);
        setLoading(false);
      }
    );

    return () => {
      console.log('useAuth: Cleaning up subscription');
      subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    console.log('Attempting sign in for:', email);
    const result = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    console.log('Sign in result:', { success: !result.error, error: result.error?.message });
    return result;
  };

  const signUp = async (email: string, password: string, fullName?: string, username?: string) => {
    console.log('Attempting sign up for:', email);
    
    // Clean and validate username - make it more robust
    let cleanUsername = username?.trim() || '';
    
    // Remove invalid characters and convert to lowercase
    cleanUsername = cleanUsername.toLowerCase().replace(/[^a-z0-9_]/g, '');
    
    // Ensure username is not empty and not too long
    if (!cleanUsername || cleanUsername.length < 3) {
      cleanUsername = `user_${Date.now().toString().slice(-8)}`;
    } else if (cleanUsername.length > 20) {
      cleanUsername = cleanUsername.substring(0, 20);
    }
    
    console.log('Cleaned username:', cleanUsername);
    
    const result = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName || '',
          username: cleanUsername,
        },
      },
    });
    
    console.log('Sign up result:', { 
      success: !result.error, 
      error: result.error?.message,
      user: !!result.data?.user,
      session: !!result.data?.session 
    });
    
    if (result.error) {
      console.error('Signup error details:', {
        message: result.error.message,
        status: result.error.status,
        details: result.error
      });
    } else if (result.data?.user) {
      console.log('User created successfully:', result.data.user.id);
    }
    
    return result;
  };

  const signOut = async () => {
    console.log('Signing out');
    const result = await supabase.auth.signOut();
    console.log('Sign out result:', { success: !result.error });
    return result;
  };

  return {
    user,
    loading,
    signIn,
    signUp,
    signOut,
  };
}