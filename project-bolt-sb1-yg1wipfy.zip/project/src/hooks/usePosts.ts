import { useState, useEffect } from 'react';
import { supabase, Post } from '../lib/supabase';
import { User } from '@supabase/supabase-js';

export function usePosts(user: User | null, showOnlyMyPosts: boolean = false) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchPosts = async () => {
    if (!user) return;

    console.log('Fetching posts (timeout-safe)...', showOnlyMyPosts ? 'My Posts Only' : 'All Posts');
    try {
      setLoading(true);
      
      // Step 1: Get posts with basic info only (with timeout protection)
      let postsQuery = supabase
        .from('posts')
        .select('id, content, image_url, likes_count, comments_count, user_id, created_at, updated_at')
        .not('user_id', 'is', null)
        .order('created_at', { ascending: false })
        .limit(10); // Reduced limit to prevent timeouts
      
      if (showOnlyMyPosts) {
        postsQuery = postsQuery.eq('user_id', user.id);
      } else {
        // For all posts, add additional filters to prevent timeouts
        const blockedIds = await getBlockedUserIds();
        if (blockedIds) {
          postsQuery = postsQuery.not('user_id', 'in', `(${blockedIds})`);
        }
      }
      
      const { data: postsData, error: postsError } = await postsQuery;

      console.log('Posts query result:', { postsData, postsError });
      if (postsError) throw postsError;

      // Step 2: Get unique user IDs and fetch profiles separately (timeout-safe)
      const userIds = [...new Set(postsData?.map(post => post.user_id) || [])];
      
      let profilesData = [];
      if (userIds.length > 0 && userIds.length <= 50) { // Limit to prevent timeouts
        const { data, error: profilesError } = await supabase
          .from('profiles')
          .select('id, username, full_name, avatar_url')
          .in('id', userIds);
        
        if (profilesError) {
          console.warn('Error fetching profiles:', profilesError);
          // Continue without profiles if there's an error
          profilesData = [];
        } else {
          profilesData = data || [];
        }
      }

      // Step 3: Create a map of user profiles for fast lookup
      const profilesMap = new Map(
        profilesData.map(profile => [profile.id, profile])
      );

      // Step 4: Check user's likes separately (timeout-safe)
      const postIds = postsData?.map(post => post.id) || [];
      
      let likedPostIds = new Set();
      if (postIds.length > 0 && postIds.length <= 50) { // Limit to prevent timeouts
        const { data: likesData } = await supabase
          .from('likes')
          .select('post_id')
          .eq('user_id', user.id)
          .in('post_id', postIds);
        
        likedPostIds = new Set(likesData?.map(like => like.post_id) || []);
      }

      // Step 5: Combine all data (with fallbacks)
      const postsWithLikes = postsData?.map(post => ({
        ...post,
        user_has_liked: likedPostIds.has(post.id),
        profiles: profilesMap.get(post.user_id) || {
          id: post.user_id,
          username: 'unknown',
          full_name: 'Unknown User',
          avatar_url: null
        },
      })) || [];

      console.log('Final posts with likes:', postsWithLikes.length);
      setPosts(postsWithLikes);
      setError(null);
    } catch (err) {
      console.error('Error fetching posts:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch posts');
    } finally {
      setLoading(false);
    }
  };

  const getBlockedUserIds = async (): Promise<string> => {
    if (!user) return '';
    
    try {
      // Get users I blocked (with timeout protection)
      const { data: blockedByMe } = await supabase
        .from('blocked_users')
        .select('blocked_user_id')
        .eq('blocker_id', user.id)
        .limit(100); // Limit to prevent timeouts
      
      // Get users who blocked me (with timeout protection)
      const { data: blockedMe } = await supabase
        .from('blocked_users')
        .select('blocker_id')
        .eq('blocked_user_id', user.id)
        .limit(100); // Limit to prevent timeouts
      
      const blockedIds = [
        ...(blockedByMe?.map(b => b.blocked_user_id) || []),
        ...(blockedMe?.map(b => b.blocker_id) || [])
      ];
      
      return blockedIds.length > 0 ? blockedIds.join(',') : '';
    } catch (error) {
      console.error('Error getting blocked user IDs:', error);
      return '';
    }
  };

  const subscribeToChanges = () => {
    if (!user) return () => {};

    console.log('Setting up real-time subscriptions...');
    const subscription = supabase
      .channel('posts-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'posts',
        },
        (payload) => {
          console.log('Posts table change:', payload);
          // Debounced refetch to avoid too many updates
          setTimeout(() => fetchPosts(), 500);
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'likes',
        },
        (payload) => {
          console.log('Likes table change:', payload);
          // Update likes optimistically without full refetch
          if (payload.eventType === 'INSERT' || payload.eventType === 'DELETE') {
            const like = payload.new || payload.old;
            if (like && like.user_id === user.id) {
              setPosts(prevPosts => 
                prevPosts.map(post => 
                  post.id === like.post_id 
                    ? { 
                        ...post, 
                        user_has_liked: payload.eventType === 'INSERT',
                        likes_count: payload.eventType === 'INSERT' 
                          ? post.likes_count + 1 
                          : Math.max(post.likes_count - 1, 0)
                      }
                    : post
                )
              );
            }
          }
        }
      )
      .subscribe();

    return () => {
      console.log('Cleaning up subscriptions');
      subscription.unsubscribe();
    };
  };

  const createPost = async (content: string, imageUrl?: string) => {
    if (!user) return { error: new Error('User not authenticated') };

    console.log('Creating post:', { content, imageUrl });
    try {
      const { data, error } = await supabase
        .from('posts')
        .insert({
          content,
          image_url: imageUrl,
          user_id: user.id,
        })
        .select()
        .single();

      console.log('Create post result:', { data, error });
      if (error) throw error;
      
      // Add new post to the beginning of the list (optimistic update)
      if (data) {
        const newPost = {
          ...data,
          user_has_liked: false,
          profiles: {
            id: user.id,
            username: 'You',
            full_name: 'You',
            avatar_url: null
          }
        };
        setPosts(prevPosts => [newPost, ...prevPosts]);
      }
      
      return { data, error: null };
    } catch (err) {
      console.error('Error creating post:', err);
      return { data: null, error: err as Error };
    }
  };

  const toggleLike = async (postId: string) => {
    if (!user) return { error: new Error('User not authenticated') };

    console.log('Toggling like for post:', postId);
    
    // Optimistic update - update UI immediately for smooth experience
    const post = posts.find(p => p.id === postId);
    if (!post) return { error: new Error('Post not found') };
    
    const wasLiked = post.user_has_liked;
    const newLikesCount = wasLiked ? post.likes_count - 1 : post.likes_count + 1;
    
    // Update UI immediately
    setPosts(prevPosts => 
      prevPosts.map(p => 
        p.id === postId 
          ? { 
              ...p, 
              user_has_liked: !wasLiked, 
              likes_count: newLikesCount 
            }
          : p
      )
    );
    
    try {
      if (wasLiked) {
        console.log('Removing like...');
        const { error } = await supabase
          .from('likes')
          .delete()
          .eq('post_id', postId)
          .eq('user_id', user.id);

        if (error) throw error;
      } else {
        console.log('Adding like...');
        const { error } = await supabase
          .from('likes')
          .insert({
            post_id: postId,
            user_id: user.id,
          });

        if (error) throw error;
      }

      console.log('Like toggled successfully');
      return { error: null };
    } catch (err) {
      console.error('Error toggling like:', err);
      
      // Revert optimistic update on error
      setPosts(prevPosts => 
        prevPosts.map(p => 
          p.id === postId 
            ? { 
                ...p, 
                user_has_liked: wasLiked, 
                likes_count: post.likes_count 
              }
            : p
        )
      );
      
      return { error: err as Error };
    }
  };

  useEffect(() => {
    if (!user) {
      setPosts([]);
      setLoading(false);
      return;
    }

    fetchPosts();
    
    const cleanup = subscribeToChanges();
    return cleanup;
  }, [user, showOnlyMyPosts]);

  const deletePost = async (postId: string) => {
    if (!user) return { error: new Error('User not authenticated') };

    console.log('Deleting post:', postId);
    try {
      // Optimistically remove from UI
      setPosts(prevPosts => prevPosts.filter(p => p.id !== postId));
      
      const { error } = await supabase
        .from('posts')
        .delete()
        .eq('id', postId)
        .eq('user_id', user.id);

      console.log('Delete post result:', { error });
      if (error) throw error;
      
      return { error: null };
    } catch (err) {
      console.error('Error deleting post:', err);
      // Revert optimistic update on error
      fetchPosts();
      return { error: err as Error };
    }
  };

  const editPost = async (postId: string, content: string, imageUrl?: string) => {
    if (!user) return { error: new Error('User not authenticated') };

    console.log('Editing post:', { postId, content, imageUrl });
    try {
      // Optimistically update UI
      setPosts(prevPosts => 
        prevPosts.map(p => 
          p.id === postId 
            ? { ...p, content, image_url: imageUrl, updated_at: new Date().toISOString() }
            : p
        )
      );
      
      const { error } = await supabase
        .from('posts')
        .update({
          content,
          image_url: imageUrl,
          updated_at: new Date().toISOString(),
        })
        .eq('id', postId)
        .eq('user_id', user.id);

      console.log('Edit post result:', { error });
      if (error) throw error;
      
      return { error: null };
    } catch (err) {
      console.error('Error editing post:', err);
      // Revert optimistic update on error
      fetchPosts();
      return { error: err as Error };
    }
  };
  
  return {
    posts,
    loading,
    error,
    createPost,
    toggleLike,
    deletePost,
    editPost,
    refetch: fetchPosts,
  };
}