import { useState, useEffect } from 'react';
import { supabase, Comment } from '../lib/supabase';
import { User } from '@supabase/supabase-js';

export function useComments(postId: string, user: User | null) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!postId || !user) {
      setComments([]);
      return;
    }

    fetchComments();
    const cleanup = subscribeToChanges();
    
    return cleanup;
  }, [postId, user]);

  const fetchComments = async () => {
    if (!postId || !user) return;

    console.log('Fetching comments for post:', postId);
    try {
      setLoading(true);
      
      // Fetch comments for this post
      const { data: commentsData, error: commentsError } = await supabase
        .from('comments')
        .select('*')
        .eq('post_id', postId)
        .order('created_at', { ascending: true });

      console.log('Comments query result:', { commentsData, commentsError });
      if (commentsError) throw commentsError;

      // Fetch profile information for each comment author
      const userIds = [...new Set(commentsData?.map(comment => comment.user_id) || [])];
      console.log('Fetching profiles for comment authors:', userIds);
      
      const { data: profilesData, error: profilesError } = await supabase
        .from('profiles')
        .select('id, username, full_name, avatar_url')
        .in('id', userIds);

      console.log('Comment profiles query result:', { profilesData, profilesError });
      if (profilesError) {
        console.warn('Error fetching comment profiles:', profilesError);
      }

      // Create a map of user profiles
      const profilesMap = new Map(
        profilesData?.map(profile => [profile.id, profile]) || []
      );

      const commentsWithProfiles = commentsData?.map(comment => ({
        ...comment,
        profiles: profilesMap.get(comment.user_id) || null,
      })) || [];

      console.log('Final comments with profiles:', commentsWithProfiles.length);
      setComments(commentsWithProfiles);
      setError(null);
    } catch (err) {
      console.error('Error fetching comments:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch comments');
    } finally {
      setLoading(false);
    }
  };

  const subscribeToChanges = () => {
    if (!postId || !user) return () => {};

    console.log('Setting up comments real-time subscription for post:', postId);
    const subscription = supabase
      .channel(`comments-${postId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'comments',
          filter: `post_id=eq.${postId}`,
        },
        (payload) => {
          console.log('Comments table change:', payload);
          fetchComments();
        }
      )
      .subscribe();

    return () => {
      console.log('Cleaning up comments subscription');
      subscription.unsubscribe();
    };
  };

  const addComment = async (content: string) => {
    if (!user || !postId) return { error: new Error('User not authenticated or post not found') };

    console.log('Adding comment:', { postId, content });
    try {
      const { data, error } = await supabase
        .from('comments')
        .insert({
          post_id: postId,
          user_id: user.id,
          content: content.trim(),
        })
        .select()
        .single();

      console.log('Add comment result:', { data, error });
      if (error) throw error;
      
      // Immediately refetch comments to show the new comment
      await fetchComments();
      
      return { data, error: null };
    } catch (err) {
      console.error('Error adding comment:', err);
      return { data: null, error: err as Error };
    }
  };

  const deleteComment = async (commentId: string) => {
    if (!user) return { error: new Error('User not authenticated') };

    console.log('Deleting comment:', commentId);
    try {
      const { error } = await supabase
        .from('comments')
        .delete()
        .eq('id', commentId)
        .eq('user_id', user.id);

      console.log('Delete comment result:', { error });
      if (error) throw error;
      
      // Immediately refetch comments to remove the deleted comment
      await fetchComments();
      
      return { error: null };
    } catch (err) {
      console.error('Error deleting comment:', err);
      return { error: err as Error };
    }
  };

  return {
    comments,
    loading,
    error,
    addComment,
    deleteComment,
    refetch: fetchComments,
  };
}