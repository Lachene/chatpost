import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "../lib/supabase";
import type { User, RealtimeChannel, RealtimePostgresChangesPayload } from "@supabase/supabase-js";

type MsgStatus = "sent" | "delivered" | "read";

export interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  status: MsgStatus;
  created_at: string;
  sender_name?: string;
  sender_avatar?: string | null;

  // local-only field to link optimistic -> server row
  client_temp_id?: string;
}

export type Conn = "connecting" | "connected" | "disconnected";

export function useChat(currentUser: User | null, otherUserId: string) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const [otherUserTyping] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<Conn>("connecting");
  const [unreadCount, setUnreadCount] = useState(0);

  const chatChannelRef = useRef<RealtimeChannel | null>(null);
  const pollRef = useRef<number | null>(null);
  const lastTsRef = useRef<string | null>(null);

  const myId = currentUser?.id ?? null;
  const room = useMemo(() => (myId ? [myId, otherUserId].sort().join("-") : ""), [myId, otherUserId]);

  function mapMessage(m: any): Message {
    return {
      ...m,
      sender_name: m.sender_id === myId ? "You" : "Friend",
      sender_avatar: m.sender_id === myId ? null : undefined,
    };
  }

  function upsertFromServer(mRaw: any) {
    const m = mapMessage(mRaw);
    setMessages((prev) => {
      // if same id already present, skip
      if (prev.some((x) => x.id === m.id)) return prev;

      // try to replace matching optimistic (same sender/receiver/content, close timestamp)
      const idx = prev.findIndex((x) =>
        x.client_temp_id &&
        x.sender_id === m.sender_id &&
        x.receiver_id === m.receiver_id &&
        x.content === m.content &&
        Math.abs(new Date(x.created_at).getTime() - new Date(m.created_at).getTime()) < 15000
      );
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = m; // replace optimistic with real row
        return copy;
      }

      // otherwise append
      return [...prev, m];
    });
  }

  // initial load
  useEffect(() => {
    let alive = true;
    (async () => {
      if (!myId || !otherUserId) {
        setMessages([]);
        setLoading(false);
        setConnectionStatus("disconnected");
        return;
      }
      setLoading(true);

      const filter =
        `and(sender_id.eq.${myId},receiver_id.eq.${otherUserId}),` +
        `and(sender_id.eq.${otherUserId},receiver_id.eq.${myId})`;

      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .or(filter)
        .order("created_at", { ascending: true })
        .limit(200);

      if (!alive) return;

      if (error) {
        setError(error.message);
        setConnectionStatus("disconnected");
      } else {
        const mapped = (data ?? []).map(mapMessage);
        setMessages(mapped);
        lastTsRef.current = mapped.length ? mapped[mapped.length - 1].created_at : null;
        setConnectionStatus("connected");
        setError(null);
      }
      setLoading(false);
    })();

    return () => {
      alive = false;
    };
  }, [myId, otherUserId]);

  // polling fallback
  useEffect(() => {
    if (!myId || !otherUserId) return;

    function start() {
      stop();
      pollRef.current = window.setInterval(async () => {
        try {
          const since = lastTsRef.current;
          const base = supabase
            .from("messages")
            .select("*")
            .or(
              `and(sender_id.eq.${myId},receiver_id.eq.${otherUserId}),` +
              `and(sender_id.eq.${otherUserId},receiver_id.eq.${myId})`
            )
            .order("created_at", { ascending: true });

          const q = since ? base.gt("created_at", since) : base;
          const { data, error } = await q;

          if (error) {
            setError((prev) => prev ?? error.message);
            return;
          }

          if (data && data.length) {
            data.forEach(upsertFromServer);
            const last = data[data.length - 1];
            if (last) lastTsRef.current = last.created_at;
          }
        } catch (e: any) {
          setError((prev) => prev ?? e?.message ?? "Polling failed");
        }
      }, 1500);
    }

    function stop() {
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    }

    start();
    return () => stop();
  }, [myId, otherUserId]);

  // realtime (non-blocking)
  useEffect(() => {
    if (!myId || !otherUserId || !room) return;

    const filter = `or(and(sender_id.eq.${myId},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${myId}))`;
    const ch = supabase.channel(`dm:${room}`);

    ch.on(
      "postgres_changes",
      { event: "*", schema: "public", table: "messages", filter },
      (payload: RealtimePostgresChangesPayload<any>) => {
        if (payload.eventType === "INSERT") {
          upsertFromServer(payload.new);
          if (payload.new.receiver_id === myId && payload.new.status !== "read") {
            setUnreadCount((c) => c + 1);
          }
        } else if (payload.eventType === "UPDATE") {
          const m = mapMessage(payload.new);
          setMessages((prev) => prev.map((x) => (x.id === m.id ? { ...x, status: m.status } : x)));
        } else if (payload.eventType === "DELETE") {
          const m = payload.old;
          setMessages((prev) => prev.filter((x) => x.id !== m.id));
        }
      }
    );

    ch.subscribe((status) => {
      if (status === "SUBSCRIBED") setConnectionStatus("connected");
    });

    chatChannelRef.current = ch;
    return () => {
      try {
        supabase.removeChannel(ch);
      } catch {}
    };
  }, [myId, otherUserId, room]);

  // actions
  async function sendMessage(content: string) {
    if (!myId || !otherUserId || !content.trim()) return { error: new Error("Invalid message") };

    // optimistic
    const tempId = crypto.randomUUID();
    const optimistic: Message = {
      id: tempId, // temporary id (will be replaced)
      client_temp_id: tempId,
      sender_id: myId,
      receiver_id: otherUserId,
      content: content.trim(),
      status: "sent",
      created_at: new Date().toISOString(),
      sender_name: "You",
      sender_avatar: null,
    };
    setMessages((prev) => [...prev, optimistic]);
    lastTsRef.current = optimistic.created_at;

    // send to server and replace optimistic with real row
    const { data, error } = await supabase
      .from("messages")
      .insert({
        sender_id: myId,
        receiver_id: otherUserId,
        content: content.trim(),
      })
      .select("*")
      .single();

    if (error) {
      setError(error.message);
      // optional: remove optimistic on error
      setMessages((prev) => prev.filter((m) => m.client_temp_id !== tempId));
      return { error };
    }

    // replace optimistic with real
    setMessages((prev) => {
      const idx = prev.findIndex((m) => m.client_temp_id === tempId);
      const real = mapMessage(data);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = real;
        return copy;
      }
      // if optimistic already replaced by realtime/polling, just ensure uniqueness
      if (prev.some((m) => m.id === real.id)) return prev;
      return [...prev, real];
    });

    lastTsRef.current = data.created_at;
    return { error: null };
  }

  async function markMessagesAsRead() {
    if (!myId || !otherUserId) return;
    const { error } = await supabase
      .from("messages")
      .update({ status: "read" })
      .or(`and(sender_id.eq.${otherUserId},receiver_id.eq.${myId})`);
    if (!error) setUnreadCount(0);
  }

  function handleTyping(v: boolean) {
    setIsTyping(Boolean(v));
  }

  function clearError() {
    setError(null);
  }

  return {
    messages,
    loading,
    error,
    clearError,
    isTyping,
    otherUserTyping,
    connectionStatus,
    unreadCount,
    sendMessage,
    handleTyping,
    markMessagesAsRead,
    refetch: () => {},
  };
}
