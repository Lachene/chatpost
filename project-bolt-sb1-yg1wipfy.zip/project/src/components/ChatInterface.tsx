import React, { useState, useEffect, useRef } from "react";
import { User } from "@supabase/supabase-js";
import { useChat } from "../hooks/useChat";
import {
  Send,
  Smile,
  MoreVertical,
  ArrowLeft,
  Check,
  CheckCheck,
  Mic,
  Wifi,
  WifiOff,
} from "lucide-react";

interface ChatInterfaceProps {
  currentUser: User;
  otherUser: {
    id: string;
    full_name: string;
    username: string;
    avatar_url?: string;
  };
  onClose: () => void;
}

export function ChatInterface({
  currentUser,
  otherUser,
  onClose,
}: ChatInterfaceProps) {
  const [newMessage, setNewMessage] = useState("");
  const [isOnline, setIsOnline] = useState(false);
  const [lastSeen, setLastSeen] = useState<string>("");

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<any>(null);

  // ✅ pass the whole User object (not currentUser.id)
  const {
    messages,
    loading,
    error,
    clearError,
    isTyping,
    otherUserTyping,
    connectionStatus,
    sendMessage,
    handleTyping,
    markMessagesAsRead,
  } = useChat(currentUser, otherUser.id);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  useEffect(() => {
    setIsOnline(Math.random() > 0.3);
    setLastSeen(new Date(Date.now() - Math.random() * 3600000).toISOString());
  }, [otherUser.id]);

  useEffect(() => {
    markMessagesAsRead();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    return () => {
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    };
  }, []);

  function handleInputChange(e: React.ChangeEvent<HTMLInputElement>) {
    const value = e.target.value;
    setNewMessage(value);

    if (value.trim() && !isTyping) handleTyping(true);
    else if (!value.trim() && isTyping) handleTyping(false);

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => handleTyping(false), 1000);
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!newMessage.trim() || connectionStatus !== "connected") return;
    await sendMessage(newMessage.trim());
    setNewMessage("");
    handleTyping(false);
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
  }

  function formatTime(s: string) {
    const d = new Date(s);
    return d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false });
  }

  function formatLastSeen(s: string) {
    const d = new Date(s);
    const now = new Date();
    const mins = Math.floor((now.getTime() - d.getTime()) / 60000);
    if (mins < 1) return "just now";
    if (mins < 60) return `${mins}m ago`;
    if (mins < 1440) return `${Math.floor(mins / 60)}h ago`;
    return d.toLocaleDateString();
  }

  function statusIcon(status: string, isSender: boolean) {
    if (!isSender) return null;
    if (status === "sent") return <Check className="w-3 h-3 text-gray-400" />;
    if (status === "delivered") return <CheckCheck className="w-3 h-3 text-gray-400" />;
    if (status === "read") return <CheckCheck className="w-3 h-3 text-blue-500" />;
    return null;
  }

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-cyan-50 to-fuchsia-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-lg border-b border-cyan-200 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>

          <div className="w-10 h-10 bg-gradient-to-r from-cyan-500 to-fuchsia-500 rounded-full flex items-center justify-center">
            {otherUser.avatar_url ? (
              <img
                src={otherUser.avatar_url}
                alt={otherUser.full_name}
                className="w-10 h-10 rounded-full object-cover"
              />
            ) : (
              <span className="text-white font-semibold">{otherUser.full_name.charAt(0)}</span>
            )}
          </div>

          <div>
            <h3 className="font-semibold text-gray-900">{otherUser.full_name}</h3>
            <div className="text-sm text-gray-500 flex items-center space-x-1">
              {connectionStatus === "connected" ? (
                <Wifi className="w-3 h-3 text-green-500" />
              ) : (
                <WifiOff className="w-3 h-3 text-red-500" />
              )}
              <span>
                {connectionStatus === "connecting" && "Connecting..."}
                {connectionStatus === "disconnected" && "Disconnected"}
                {connectionStatus === "connected" &&
                  (isOnline ? "Online" : `Last seen ${formatLastSeen(lastSeen)}`)}
              </span>
            </div>
            {otherUserTyping && <span className="text-cyan-500 text-xs animate-pulse">typing...</span>}
          </div>
        </div>

        <button className="p-2 hover:bg-gray-100 rounded-full">
          <MoreVertical className="w-5 h-5 text-gray-600" />
        </button>
      </div>

      {/* Error */}
      {error && (
        <div className="px-4 py-2 bg-red-50 border-b border-red-200">
          <p className="text-red-600 text-sm">{error}</p>
          <button onClick={clearError} className="text-red-500 hover:text-red-700 text-xs underline">
            Dismiss
          </button>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {loading && <div className="text-cyan-600">Loading chat…</div>}

        {!loading &&
          messages.map((m) => {
            const mine = m.sender_id === currentUser.id;
            return (
              <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl shadow-sm ${
                    mine
                      ? "bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white"
                      : "bg-white text-gray-900 border border-gray-200"
                  }`}
                >
                  <p className="text-sm">{m.content}</p>
                  <div
                    className={`flex items-center justify-end space-x-1 mt-1 ${
                      mine ? "text-white/80" : "text-gray-500"
                    }`}
                  >
                    <span className="text-xs">{formatTime(m.created_at)}</span>
                    {statusIcon(m.status, mine)}
                  </div>
                </div>
              </div>
            );
          })}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="border-t border-gray-200 p-4 bg-white/80 backdrop-blur-lg">
        <form onSubmit={onSubmit} className="flex items-center space-x-2">
          <div className="flex-1 relative">
            <input
              type="text"
              value={newMessage}
              onChange={handleInputChange}
              placeholder="Type a message..."
              className="w-full px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
              // ✅ allow typing while "connecting"; only block when disconnected
              disabled={connectionStatus === "disconnected"}
              maxLength={1000}
            />
            {isTyping && <div className="absolute -top-6 left-4 text-xs text-cyan-500">typing...</div>}
          </div>

          <button type="button" className="p-2 hover:bg-gray-100 rounded-full">
            <Smile className="w-5 h-5 text-gray-600" />
          </button>

          {newMessage.trim() ? (
            <button
              type="submit"
              // Only allow sending once connected
              disabled={connectionStatus !== "connected"}
              className="bg-gradient-to-r from-cyan-500 to-fuchsia-500 hover:from-cyan-600 hover:to-fuchsia-600 text-white p-2 rounded-full disabled:opacity-50"
            >
              <Send className="w-5 h-5" />
            </button>
          ) : (
            <button
              type="button"
              disabled={connectionStatus !== "connected"}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <Mic className="w-5 h-5 text-gray-600" />
            </button>
          )}
        </form>
      </div>
    </div>
  );
}
