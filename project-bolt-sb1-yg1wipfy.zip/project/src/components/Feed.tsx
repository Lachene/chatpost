import React, { useState, useEffect } from 'react';
import { User } from '@supabase/supabase-js';
import { usePosts } from '../hooks/usePosts';
import { useProfile } from '../hooks/useProfile';
import { useSocial } from '../hooks/useSocial';
import { PostCard } from './PostCard';
import { CreatePost } from './CreatePost';
import { UserProfile } from './UserProfile';
import { ChatInterface } from './ChatInterface';
import { FriendRequestNotifications } from './FriendRequestNotifications';
import { 
  Plus, 
  Search, 
  User as UserIcon, 
  MessageCircle, 
  Users, 
  Home,
  Settings,
  LogOut,
  Sparkles
} from 'lucide-react';

interface FeedProps {
  user: User;
  onSignOut: () => void;
}

export function Feed({ user, onSignOut }: FeedProps) {
  const [activeTab, setActiveTab] = useState<'home' | 'profile' | 'friends' | 'search'>('home');
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState<any>(null);
  const [showChat, setShowChat] = useState(false);
  const [chatUser, setChatUser] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);
  const [showOnlyMyPosts, setShowOnlyMyPosts] = useState(false);

  const { posts, loading: postsLoading, createPost, toggleLike, deletePost, editPost } = usePosts(user, showOnlyMyPosts);
  const { profile, loading: profileLoading } = useProfile(user);
  const { searchUsers, sendFriendRequest, getFriends } = useSocial(user);

  const friends = getFriends();

  useEffect(() => {
    const handleSearch = async () => {
      if (!searchQuery.trim()) {
        setSearchResults([]);
        return;
      }

      setSearching(true);
      try {
        const results = await searchUsers(searchQuery);
        setSearchResults(results);
      } catch (error) {
        console.error('Search error:', error);
      } finally {
        setSearching(false);
      }
    };

    const debounceTimer = setTimeout(handleSearch, 300);
    return () => clearTimeout(debounceTimer);
  }, [searchQuery, searchUsers]);

  const handleStartChat = (friend: any) => {
    setChatUser(friend);
    setShowChat(true);
  };

  const handleViewProfile = (profileData: any) => {
    setSelectedProfile(profileData);
    setActiveTab('profile');
  };

  const handleSendFriendRequest = async (userId: string) => {
    try {
      const result = await sendFriendRequest(userId);
      if (result.error) {
        alert('Failed to send friend request: ' + result.error.message);
      } else {
        alert('Friend request sent!');
        // Update search results to reflect sent request
        setSearchResults(prev => 
          prev.map(user => 
            user.id === userId 
              ? { ...user, friend_request_sent: true }
              : user
          )
        );
      }
    } catch (error) {
      console.error('Error sending friend request:', error);
      alert('Failed to send friend request');
    }
  };

  if (showChat && chatUser) {
    return (
      <ChatInterface
        currentUser={user}
        otherUser={chatUser}
        onClose={() => {
          setShowChat(false);
          setChatUser(null);
        }}
      />
    );
  }

  if (profileLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-fuchsia-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-cyan-600 font-medium">Loading your profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-fuchsia-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-lg border-b border-cyan-200 sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-lg overflow-hidden">
                <img 
                  src="/CHITCHAT.jpg" 
                  alt="ChitChat Logo" 
                  className="w-8 h-8 object-cover"
                />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-600 to-fuchsia-600 bg-clip-text text-transparent">
                ChitChat
              </h1>
            </div>

            <nav className="hidden md:flex items-center space-x-6">
              <button
                onClick={() => setActiveTab('home')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  activeTab === 'home'
                    ? 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white'
                    : 'text-gray-600 hover:text-cyan-600'
                }`}
              >
                <Home className="w-4 h-4" />
                <span>Home</span>
              </button>

              <button
                onClick={() => setActiveTab('friends')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  activeTab === 'friends'
                    ? 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white'
                    : 'text-gray-600 hover:text-cyan-600'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Friends</span>
              </button>

              <button
                onClick={() => setActiveTab('search')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  activeTab === 'search'
                    ? 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white'
                    : 'text-gray-600 hover:text-cyan-600'
                }`}
              >
                <Search className="w-4 h-4" />
                <span>Search</span>
              </button>
            </nav>

            <div className="flex items-center space-x-3">
              <button
                onClick={() => setShowCreatePost(true)}
                className="bg-gradient-to-r from-cyan-500 to-fuchsia-500 hover:from-cyan-600 hover:to-fuchsia-600 text-white p-2 rounded-full transition-colors shadow-lg"
              >
                <Plus className="w-5 h-5" />
              </button>

              <button
                onClick={() => {
                  setSelectedProfile(profile);
                  setActiveTab('profile');
                }}
                className="w-10 h-10 bg-gradient-to-r from-cyan-500 to-fuchsia-500 rounded-full flex items-center justify-center hover:scale-105 transition-transform"
              >
                {profile?.avatar_url ? (
                  <img
                    src={profile.avatar_url}
                    alt={profile.full_name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                ) : (
                  <UserIcon className="w-5 h-5 text-white" />
                )}
              </button>

              <button
                onClick={onSignOut}
                className="p-2 text-gray-600 hover:text-red-600 transition-colors"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Navigation */}
      <div className="md:hidden bg-white/80 backdrop-blur-lg border-b border-cyan-200 sticky top-16 z-30">
        <div className="flex items-center justify-around py-2">
          <button
            onClick={() => setActiveTab('home')}
            className={`flex flex-col items-center space-y-1 px-4 py-2 ${
              activeTab === 'home' ? 'text-cyan-600' : 'text-gray-600'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-xs">Home</span>
          </button>

          <button
            onClick={() => setActiveTab('friends')}
            className={`flex flex-col items-center space-y-1 px-4 py-2 ${
              activeTab === 'friends' ? 'text-cyan-600' : 'text-gray-600'
            }`}
          >
            <Users className="w-5 h-5" />
            <span className="text-xs">Friends</span>
          </button>

          <button
            onClick={() => setActiveTab('search')}
            className={`flex flex-col items-center space-y-1 px-4 py-2 ${
              activeTab === 'search' ? 'text-cyan-600' : 'text-gray-600'
            }`}
          >
            <Search className="w-5 h-5" />
            <span className="text-xs">Search</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-6">
        {activeTab === 'home' && (
          <div className="space-y-6">
            {/* Friend Request Notifications */}
            <FriendRequestNotifications user={user} />

            {/* Toggle for My Posts */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-900">Posts</h2>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setShowOnlyMyPosts(false)}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                      !showOnlyMyPosts
                        ? 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white'
                        : 'text-gray-600 hover:text-cyan-600'
                    }`}
                  >
                    All Posts
                  </button>
                  <button
                    onClick={() => setShowOnlyMyPosts(true)}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                      showOnlyMyPosts
                        ? 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white'
                        : 'text-gray-600 hover:text-cyan-600'
                    }`}
                  >
                    My Posts
                  </button>
                </div>
              </div>
            </div>

            {/* Posts Feed */}
            {postsLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="text-center">
                  <div className="w-8 h-8 border-2 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin mx-auto mb-4" />
                  <p className="text-cyan-600 font-medium">Loading posts...</p>
                </div>
              </div>
            ) : posts.length > 0 ? (
              <div className="space-y-6">
                {posts.map((post) => (
                  <PostCard
                    key={post.id}
                    post={post}
                    currentUser={user}
                    onLike={toggleLike}
                    onDelete={deletePost}
                    onEdit={editPost}
                    onViewProfile={handleViewProfile}
                  />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
                <Sparkles className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {showOnlyMyPosts ? "You haven't posted anything yet" : "No posts yet"}
                </h3>
                <p className="text-gray-600 mb-6">
                  {showOnlyMyPosts 
                    ? "Share your first post to get started!" 
                    : "Be the first to share something amazing!"
                  }
                </p>
                <button
                  onClick={() => setShowCreatePost(true)}
                  className="bg-gradient-to-r from-cyan-500 to-fuchsia-500 hover:from-cyan-600 hover:to-fuchsia-600 text-white px-6 py-3 rounded-lg font-medium transition-colors"
                >
                  Create Post
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'friends' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Your Friends</h2>
              
              {friends.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {friends.map((friend) => (
                    <div key={friend.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-cyan-500 to-fuchsia-500 rounded-full flex items-center justify-center">
                          {friend.avatar_url ? (
                            <img
                              src={friend.avatar_url}
                              alt={friend.full_name}
                              className="w-10 h-10 rounded-full object-cover"
                            />
                          ) : (
                            <UserIcon className="w-5 h-5 text-white" />
                          )}
                        </div>
                        <div>
                          <p className="font-semibold text-gray-900">{friend.full_name}</p>
                          <p className="text-sm text-gray-500">@{friend.username}</p>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleViewProfile(friend)}
                          className="p-2 text-gray-600 hover:text-cyan-600 transition-colors"
                        >
                          <UserIcon className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleStartChat(friend)}
                          className="p-2 text-gray-600 hover:text-cyan-600 transition-colors"
                        >
                          <MessageCircle className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No friends yet</h3>
                  <p className="text-gray-600 mb-4">Search for people to connect with!</p>
                  <button
                    onClick={() => setActiveTab('search')}
                    className="bg-gradient-to-r from-cyan-500 to-fuchsia-500 hover:from-cyan-600 hover:to-fuchsia-600 text-white px-6 py-3 rounded-lg font-medium transition-colors"
                  >
                    Find Friends
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'search' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Find People</h2>
              
              <div className="relative mb-6">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by name or username..."
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
                />
              </div>

              {searching && (
                <div className="flex items-center justify-center py-8">
                  <div className="w-6 h-6 border-2 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin" />
                </div>
              )}

              {searchResults.length > 0 && (
                <div className="space-y-4">
                  {searchResults.map((searchUser) => (
                    <div key={searchUser.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-cyan-500 to-fuchsia-500 rounded-full flex items-center justify-center">
                          {searchUser.avatar_url ? (
                            <img
                              src={searchUser.avatar_url}
                              alt={searchUser.full_name}
                              className="w-10 h-10 rounded-full object-cover"
                            />
                          ) : (
                            <UserIcon className="w-5 h-5 text-white" />
                          )}
                        </div>
                        <div>
                          <p className="font-semibold text-gray-900">{searchUser.full_name}</p>
                          <p className="text-sm text-gray-500">@{searchUser.username}</p>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleViewProfile(searchUser)}
                          className="px-4 py-2 text-gray-600 hover:text-cyan-600 border border-gray-300 rounded-lg font-medium transition-colors"
                        >
                          View Profile
                        </button>
                        <button
                          onClick={() => handleSendFriendRequest(searchUser.id)}
                          disabled={searchUser.friend_request_sent}
                          className="bg-gradient-to-r from-cyan-500 to-fuchsia-500 hover:from-cyan-600 hover:to-fuchsia-600 text-white px-4 py-2 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {searchUser.friend_request_sent ? 'Request Sent' : 'Add Friend'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {searchQuery && !searching && searchResults.length === 0 && (
                <div className="text-center py-8">
                  <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No results found</h3>
                  <p className="text-gray-600">Try searching with a different name or username.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'profile' && selectedProfile && (
          <UserProfile
            user={user}
            profile={selectedProfile}
            isOwnProfile={selectedProfile.id === user.id}
            onStartChat={() => handleStartChat(selectedProfile)}
            onSendFriendRequest={() => handleSendFriendRequest(selectedProfile.id)}
          />
        )}
      </main>

      {/* Create Post Modal */}
      {showCreatePost && (
        <CreatePost
          user={user}
          onClose={() => setShowCreatePost(false)}
          onPostCreated={createPost}
        />
      )}
    </div>
  );
}
