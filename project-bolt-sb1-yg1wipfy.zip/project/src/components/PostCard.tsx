import React, { useState } from 'react';
import { Post } from '../lib/supabase';
import { useComments } from '../hooks/useComments';
import { CommentSection } from './CommentSection';
import { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { 
  Heart, 
  MessageCircle, 
  Share, 
  MoreHorizontal,
  Trash2,
  Edit3,
  Save,
  X,
  User as UserIcon,
  Smile,
  Copy,
  Send
} from 'lucide-react';

interface PostCardProps {
  post: Post;
  currentUser: User | null;
  onLike: (postId: string) => void;
  onDelete?: (postId: string) => void;
  onEdit?: (postId: string, content: string, imageUrl?: string) => void;
  onViewProfile?: (profile: any) => void;
}

export function PostCard({ post, currentUser, onLike, onDelete, onEdit, onViewProfile }: PostCardProps) {
  const [showMenu, setShowMenu] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(post.content);
  const [editImageUrl, setEditImageUrl] = useState(post.image_url || '');
  const [saving, setSaving] = useState(false);
  
  const [showReactions, setShowReactions] = useState(false);
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [reactions, setReactions] = useState<any[]>([]);
  const [userReaction, setUserReaction] = useState<string | null>(null);
  const [isShared, setIsShared] = useState(false);
  const [reactionAnimating, setReactionAnimating] = useState<string | null>(null);
  const [shareAnimating, setShareAnimating] = useState(false);
  
  const { comments, loading: commentsLoading, addComment, deleteComment } = useComments(
    post.id, 
    currentUser
  );

  const reactionEmojis = ['❤️', '😂', '😮', '😢', '😡', '👍', '👎', '🔥', '💯', '🎉'];
  
  // Load reactions on component mount
  React.useEffect(() => {
    loadReactions();
  }, [post.id]);
  
  // Close menus when clicking outside
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      if (!target.closest('.reaction-menu') && !target.closest('.share-menu')) {
        setShowReactions(false);
        setShowShareMenu(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);
  
  const loadReactions = async () => {
    try {
      const { data, error } = await supabase
        .from('post_reactions')
        .select('*')
        .eq('post_id', post.id);
      
      if (!error && data) {
        setReactions(data);
        const myReaction = data.find(r => r.user_id === currentUser?.id);
        setUserReaction(myReaction?.reaction || null);
      }
    } catch (error) {
      console.error('Error loading reactions:', error);
    }
  };
  
  const handleReaction = async (emoji: string) => {
    if (!currentUser) return;
    
    // Animate reaction
    setReactionAnimating(emoji);
    setTimeout(() => setReactionAnimating(null), 600);
    
    try {
      const { data, error } = await supabase.rpc('toggle_post_reaction', {
        post_id_param: post.id,
        reaction_param: emoji
      });
      
      if (!error) {
        await loadReactions(); // Reload reactions
        setShowReactions(false);
      }
    } catch (error) {
      console.error('Error handling reaction:', error);
    }
  };
  
  const copyToClipboard = async () => {
    const shareUrl = `${window.location.origin}/post/${post.id}`;
    try {
      await navigator.clipboard.writeText(shareUrl);
      alert('Link copied to clipboard! 📋');
    } catch (error) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = shareUrl;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      alert('Link copied to clipboard! 📋');
    }
  };
  
  const shareToWhatsApp = () => {
    const shareUrl = `${window.location.origin}/post/${post.id}`;
    const text = `Check out this post on ChitChat: ${post.content.substring(0, 100)}${post.content.length > 100 ? '...' : ''}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(text + '\n\n' + shareUrl)}`;
    window.open(whatsappUrl, '_blank');
  };
  
  const shareToInstagram = () => {
    // Instagram doesn't support direct sharing via URL, so we copy the link
    copyToClipboard();
    alert('Link copied! You can now paste it in Instagram Stories or DMs 📸');
  };
  
  const shareToTwitter = () => {
    const shareUrl = `${window.location.origin}/post/${post.id}`;
    const text = `Check out this post on ChitChat: ${post.content.substring(0, 200)}${post.content.length > 200 ? '...' : ''}`;
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(shareUrl)}`;
    window.open(twitterUrl, '_blank');
  };
  
  const handleShareToggle = async () => {
    if (!currentUser) return;
    
    setShareAnimating(true);
    setTimeout(() => setShareAnimating(false), 300);
    
    try {
      const { data, error } = await supabase.rpc('share_post', {
        post_id_param: post.id
      });
      
      if (!error) {
        setIsShared(!isShared);
      }
    } catch (error) {
      console.error('Error sharing post:', error);
    }
  };
  
  const getReactionCounts = () => {
    const counts: { [key: string]: number } = {};
    reactions.forEach(reaction => {
      counts[reaction.reaction] = (counts[reaction.reaction] || 0) + 1;
    });
    return counts;
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffInSeconds < 60) return 'just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)}d`;
    
    return date.toLocaleDateString();
  };

  const canEdit = () => {
    if (!currentUser || currentUser.id !== post.user_id) return false;
    
    const postDate = new Date(post.created_at);
    const now = new Date();
    const daysDiff = Math.floor((now.getTime() - postDate.getTime()) / (1000 * 60 * 60 * 24));
    
    return daysDiff <= 7;
  };

  const handleEdit = async () => {
    if (!onEdit || saving) return;
    
    setSaving(true);
    try {
      await onEdit(post.id, editContent.trim(), editImageUrl.trim() || undefined);
      setIsEditing(false);
      setShowMenu(false);
    } catch (error) {
      console.error('Failed to edit post:', error);
      alert('Failed to edit post');
    } finally {
      setSaving(false);
    }
  };

  const cancelEdit = () => {
    setEditContent(post.content);
    setEditImageUrl(post.image_url || '');
    setIsEditing(false);
  };
  
  const canDelete = currentUser?.id === post.user_id;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow duration-200">
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <button
            onClick={() => onViewProfile?.(post.profiles)}
            className="w-10 h-10 bg-gradient-to-r from-cyan-500 to-fuchsia-500 rounded-full flex items-center justify-center hover:scale-105 transition-transform"
          >
            {post.profiles?.avatar_url && !imageError ? (
              <img
                src={post.profiles.avatar_url}
                alt={post.profiles.full_name}
                className="w-10 h-10 rounded-full object-cover"
                onError={() => setImageError(true)}
              />
            ) : (
              <UserIcon className="w-5 h-5 text-white" />
            )}
          </button>
          <div>
            <button
              onClick={() => onViewProfile?.(post.profiles)}
              className="font-semibold text-gray-900 hover:text-cyan-600 transition-colors text-left flex items-center space-x-2"
            >
              <span>{post.profiles?.full_name || 'Unknown User'}</span>
              {post.profiles?.owner_tag === 'OWNER' && (
                <span className="bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white text-xs px-2 py-1 rounded-full font-bold shadow-sm">
                  OWNER
                </span>
              )}
            </button>
            <p className="text-sm text-gray-500">
              <button
                onClick={() => onViewProfile?.(post.profiles)}
                className="hover:text-cyan-600 transition-colors"
              >
                @{post.profiles?.username}
              </button>
              {' • '}
              {formatTimeAgo(post.created_at)}
              {post.updated_at !== post.created_at && (
                <span className="text-xs text-gray-400 ml-1">(edited)</span>
              )}
            </p>
          </div>
        </div>

        {(canDelete || canEdit()) && (
          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <MoreHorizontal className="w-4 h-4 text-gray-500" />
            </button>

            {showMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 z-10">
                {canEdit() && (
                  <button
                    onClick={() => {
                      setIsEditing(true);
                      setShowMenu(false);
                    }}
                    className="flex items-center space-x-2 px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 w-full text-left rounded-lg"
                  >
                    <Edit3 className="w-4 h-4" />
                    <span>Edit Post</span>
                  </button>
                )}
                {canDelete && (
                  <button
                    onClick={() => {
                      onDelete?.(post.id);
                      setShowMenu(false);
                    }}
                    className="flex items-center space-x-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50 w-full text-left rounded-lg"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Delete Post</span>
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Content - Editable */}
      {isEditing ? (
        <div className="px-4 pb-3 space-y-4">
          <textarea
            value={editContent}
            onChange={(e) => setEditContent(e.target.value)}
            className="w-full resize-none border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
            rows={3}
            maxLength={500}
            placeholder="Edit your post..."
          />
          
          {post.image_url && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Image URL (optional)
              </label>
              <input
                type="url"
                value={editImageUrl}
                onChange={(e) => setEditImageUrl(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
                placeholder="Enter image URL..."
              />
            </div>
          )}
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-500">
              {editContent.length}/500
            </span>
            <div className="flex space-x-2">
              <button
                onClick={cancelEdit}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
              <button
                onClick={handleEdit}
                disabled={saving || !editContent.trim()}
                className="bg-gradient-to-r from-cyan-500 to-fuchsia-500 hover:from-cyan-600 hover:to-fuchsia-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-1"
              >
                {saving ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Save className="w-4 h-4" />
                )}
                <span>{saving ? 'Saving...' : 'Save'}</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="px-4 pb-3">
          <p className="text-gray-900 whitespace-pre-wrap leading-relaxed">
            {post.content}
          </p>
        </div>
      )}

      {/* Image */}
      {(isEditing ? editImageUrl : post.image_url) && (
        <div className="px-4 pb-3">
          <img
            src={isEditing ? editImageUrl : post.image_url}
            alt="Post content"
            className="w-full rounded-lg object-cover max-h-96 cursor-pointer"
            onError={(e) => {
              e.currentTarget.style.display = 'none';
            }}
            onDoubleClick={() => !isEditing && handleReaction('❤️')}
          />
        </div>
      )}
      
      {/* Reactions Display - Only show if there are reactions */}
      {reactions.length > 0 && (
        <div className="px-4 pb-2">
          <div className="flex items-center flex-wrap gap-2">
            <div className="flex flex-wrap gap-2">
              {Object.entries(getReactionCounts()).map(([emoji, count]) => (
                <button
                  key={emoji}
                  onClick={() => handleReaction(emoji)}
                  className={`bg-gradient-to-r from-cyan-50 to-fuchsia-50 hover:from-cyan-100 hover:to-fuchsia-100 rounded-full px-2 py-1 text-xs flex items-center space-x-1 border transition-all duration-200 ${
                    userReaction === emoji 
                      ? 'border-cyan-400 bg-gradient-to-r from-cyan-100 to-fuchsia-100 scale-105' 
                      : 'border-cyan-200 hover:scale-105'
                  }`}
                >
                  <span className="text-sm">{emoji}</span>
                  <span className="text-cyan-600 font-semibold text-xs">{count}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="px-4 py-3 border-t border-gray-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <button
              onClick={() => onLike(post.id)}
              disabled={isEditing}
              className={`flex items-center space-x-2 transition-all duration-200 ${
                post.user_has_liked
                  ? 'text-red-500 hover:text-red-600 scale-105'
                  : 'text-gray-500 hover:text-red-500 hover:scale-105'
              } ${isEditing ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <Heart
                className={`w-5 h-5 transition-all duration-200 ${post.user_has_liked ? 'fill-current animate-pulse' : ''}`}
              />
              <span className="text-sm font-medium">{post.likes_count}</span>
            </button>

            <button 
              onClick={() => setShowComments(!showComments)}
              disabled={isEditing}
              className={`flex items-center space-x-2 transition-all duration-200 ${
                showComments 
                  ? 'text-blue-500 scale-105' 
                  : 'text-gray-500 hover:text-blue-500 hover:scale-105'
              } ${isEditing ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <MessageCircle className="w-5 h-5" />
              <span className="text-sm font-medium">{post.comments_count}</span>
            </button>

            <div className="relative reaction-menu">
              <button 
                onClick={() => setShowReactions(!showReactions)}
                disabled={isEditing}
                className={`flex items-center space-x-2 transition-all duration-200 ${
                  userReaction 
                    ? 'text-fuchsia-500 scale-105' 
                    : 'text-gray-500 hover:text-fuchsia-500 hover:scale-105'
                } ${isEditing ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <Smile className={`w-5 h-5 transition-all duration-200 ${userReaction ? 'animate-pulse' : ''}`} />
                <span className="text-sm font-medium">{reactions.length}</span>
              </button>
              
              {/* Reactions popup */}
              {showReactions && (
                <div className="absolute bottom-full left-0 mb-2 bg-white/95 backdrop-blur-sm rounded-xl shadow-lg border border-cyan-200 p-2 flex flex-wrap gap-1 z-20 animate-in slide-in-from-bottom-2 duration-300">
                  {reactionEmojis.map(emoji => (
                    <button
                      key={emoji}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleReaction(emoji);
                      }}
                      className={`hover:scale-110 transition-all duration-200 p-1 text-sm rounded-md relative ${
                        userReaction === emoji 
                          ? 'bg-gradient-to-r from-cyan-100 to-fuchsia-100 scale-105 shadow-sm' 
                          : 'hover:bg-gradient-to-r hover:from-cyan-50 hover:to-fuchsia-50'
                      } ${reactionAnimating === emoji ? 'animate-bounce' : ''}`}
                    >
                      {emoji}
                      {reactionAnimating === emoji && (
                        <div className="absolute inset-0 rounded-md bg-gradient-to-r from-cyan-400 to-fuchsia-400 opacity-20 animate-ping" />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="relative share-menu">
              <button 
                onClick={() => setShowShareMenu(!showShareMenu)}
                disabled={isEditing}
                className={`flex items-center space-x-2 transition-all duration-200 ${
                  isShared 
                    ? 'text-green-500 scale-105' 
                    : 'text-gray-500 hover:text-green-500 hover:scale-105'
                } ${
                  isEditing ? 'opacity-50 cursor-not-allowed' : ''
                } ${shareAnimating ? 'animate-pulse' : ''}`}
              >
                <Share className={`w-5 h-5 transition-all duration-200 ${isShared ? 'fill-current' : ''}`} />
                <span className="text-sm font-medium">{post.shares_count || 0}</span>
              </button>
              
              {/* Share Menu */}
              {showShareMenu && (
                <div className="absolute bottom-full left-0 mb-2 bg-white/95 backdrop-blur-sm rounded-xl shadow-lg border border-cyan-200 p-2 min-w-44 z-20 animate-in slide-in-from-bottom-2 duration-300">
                  <div className="space-y-2">
                    <button
                      onClick={() => {
                        shareToWhatsApp();
                        setShowShareMenu(false);
                      }}
                      className="w-full flex items-center space-x-2 px-2 py-1.5 text-left hover:bg-gradient-to-r hover:from-green-50 hover:to-green-100 rounded-md transition-all duration-200"
                    >
                      <span className="text-lg">💬</span>
                      <span className="text-xs font-medium text-gray-700">WhatsApp</span>
                    </button>
                    
                    <button
                      onClick={() => {
                        shareToInstagram();
                        setShowShareMenu(false);
                      }}
                      className="w-full flex items-center space-x-2 px-2 py-1.5 text-left hover:bg-gradient-to-r hover:from-pink-50 hover:to-pink-100 rounded-md transition-all duration-200"
                    >
                      <span className="text-lg">📸</span>
                      <span className="text-xs font-medium text-gray-700">Instagram</span>
                    </button>
                    
                    <button
                      onClick={() => {
                        shareToTwitter();
                        setShowShareMenu(false);
                      }}
                      className="w-full flex items-center space-x-2 px-2 py-1.5 text-left hover:bg-gradient-to-r hover:from-blue-50 hover:to-blue-100 rounded-md transition-all duration-200"
                    >
                      <span className="text-lg">🐦</span>
                      <span className="text-xs font-medium text-gray-700">Twitter</span>
                    </button>
                    
                    <div className="border-t border-gray-200 my-2"></div>
                    
                    <button
                      onClick={() => {
                        copyToClipboard();
                        setShowShareMenu(false);
                      }}
                      className="w-full flex items-center space-x-2 px-2 py-1.5 text-left hover:bg-gradient-to-r hover:from-cyan-50 hover:to-fuchsia-50 rounded-md transition-all duration-200"
                    >
                      <Copy className="w-3 h-3 text-cyan-600" />
                      <span className="text-xs font-medium text-gray-700">Copy Link</span>
                    </button>
                    
                    <button
                      onClick={() => {
                        handleShareToggle();
                        setShowShareMenu(false);
                      }}
                      className="w-full flex items-center space-x-2 px-2 py-1.5 text-left hover:bg-gradient-to-r hover:from-fuchsia-50 hover:to-cyan-50 rounded-md transition-all duration-200"
                    >
                      <Send className="w-3 h-3 text-fuchsia-600" />
                      <span className="text-xs font-medium text-gray-700">
                        {isShared ? 'Remove from Shared' : 'Add to Shared'}
                      </span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Comments Section */}
      {showComments && !isEditing && (
        <div className="px-4 pb-4">
          <CommentSection
            comments={comments}
            onAddComment={addComment}
            onDeleteComment={deleteComment}
            currentUserId={currentUser?.id}
            loading={commentsLoading}
          />
        </div>
      )}
    </div>
  );
}