import React, { useState, useEffect } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { useSocial } from '../hooks/useSocial';
import { BlockedUsers } from './BlockedUsers';
import { 
  User as UserIcon, 
  MessageCircle, 
  UserPlus, 
  UserCheck,
  UserX,
  Shield,
  ShieldOff,
  Settings, 
  Calendar,
  MapPin,
  Link as LinkIcon,
  Edit3,
  Camera,
  Save,
  X,
  AlertCircle,
  Clock,
  Upload,
  Image as ImageIcon
} from 'lucide-react';

interface UserProfileProps {
  user: User;
  profile: any;
  isOwnProfile: boolean;
  onStartChat?: () => void;
  onSendFriendRequest?: () => void;
}

export function UserProfile({ 
  user, 
  profile, 
  isOwnProfile, 
  onStartChat, 
  onSendFriendRequest 
}: UserProfileProps) {
  const { getFriends, getSentRequests, getPendingRequests, sendFriendRequest, cancelFriendRequest } = useSocial(user);
  const [isEditing, setIsEditing] = useState(false);
  const [editedProfile, setEditedProfile] = useState({
    full_name: profile?.full_name || '',
    username: profile?.username || '',
    bio: profile?.bio || '',
    location: profile?.location || '',
    website: profile?.website || '',
    avatar_url: profile?.avatar_url || '',
    banner_url: profile?.banner_url || ''
  });
  const [saving, setSaving] = useState(false);
  const [userPosts, setUserPosts] = useState<any[]>([]);
  const [postsLoading, setPostsLoading] = useState(true);
  const [canChangeUsername, setCanChangeUsername] = useState(true);
  const [daysUntilUsernameChange, setDaysUntilUsernameChange] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [uploadingImage, setUploadingImage] = useState<'avatar' | 'banner' | null>(null);
  const [friendshipStatus, setFriendshipStatus] = useState<'none' | 'pending_sent' | 'pending_received' | 'friends'>('none');
  const [actualProfile, setActualProfile] = useState<any>(null);

  const [showBlockedUsers, setShowBlockedUsers] = useState(false);
  const [isBlocked, setIsBlocked] = useState(false);
  const [hasBlockedMe, setHasBlockedMe] = useState(false);

  useEffect(() => {
    if (profile) {
      setEditedProfile({
        full_name: profile.full_name || '',
        username: profile.username || '',
        bio: profile.bio || '',
        location: profile.location || '',
        website: profile.website || '',
        avatar_url: profile.avatar_url || '',
        banner_url: profile.banner_url || ''
      });
      fetchUserProfile();
      if (isOwnProfile) {
        checkUsernameChangeStatus();
      } else {
        checkFriendshipStatus();
        checkBlockStatus();
      }
    }
  }, [profile, isOwnProfile]);

  const fetchUserProfile = async () => {
    if (!profile?.id) return;
    
    try {
      // Fetch the actual profile with correct counts
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', profile.id)
        .single();

      if (profileError) throw profileError;
      
      console.log('Fetched actual profile:', profileData);
      setActualProfile(profileData);
      
      // Also fetch posts
      fetchUserPosts();
    } catch (error) {
      console.error('Error fetching user profile:', error);
    }
  };

  const checkFriendshipStatus = async () => {
    if (!profile?.id || isOwnProfile) return;
    
    try {
      console.log('Checking friendship status with:', profile.id);
      
      // Check if there's a friend request between users
      const { data: friendRequest, error } = await supabase
        .from('friend_requests')
        .select('*')
        .or(`and(sender_id.eq.${user.id},receiver_id.eq.${profile.id}),and(sender_id.eq.${profile.id},receiver_id.eq.${user.id})`)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        console.error('Error checking friendship:', error);
        return;
      }

      if (!friendRequest) {
        setFriendshipStatus('none');
      } else if (friendRequest.status === 'accepted') {
        setFriendshipStatus('friends');
      } else if (friendRequest.sender_id === user.id) {
        setFriendshipStatus('pending_sent');
      } else {
        setFriendshipStatus('pending_received');
      }
      
      console.log('Friendship status:', friendRequest?.status || 'none');
    } catch (error) {
      console.error('Error checking friendship status:', error);
    }
  };

  const checkBlockStatus = async () => {
    if (!profile?.id || isOwnProfile) return;
    
    try {
      // Check if I blocked them
      const { data: iBlockedThem } = await supabase
        .from('blocked_users')
        .select('id')
        .eq('blocker_id', user.id)
        .eq('blocked_user_id', profile.id)
        .maybeSingle();
      
      setIsBlocked(!!iBlockedThem);
      
      // Check if they blocked me
      const { data: theyBlockedMe } = await supabase
        .from('blocked_users')
        .select('id')
        .eq('blocker_id', profile.id)
        .eq('blocked_user_id', user.id)
        .maybeSingle();
      
      setHasBlockedMe(!!theyBlockedMe);
      
    } catch (error) {
      console.error('Error checking block status:', error);
    }
  };

  const handleBlock = async () => {
    if (!profile?.id) return;
    
    if (isBlocked) {
      // Unblock
      try {
        const { error } = await supabase
          .from('blocked_users')
          .delete()
          .eq('blocker_id', user.id)
          .eq('blocked_user_id', profile.id);
        
        if (error) throw error;
        setIsBlocked(false);
        alert('User unblocked');
      } catch (error) {
        console.error('Error unblocking:', error);
        alert('Failed to unblock user');
      }
    } else {
      // Block
      if (confirm(`Are you sure you want to block ${profile.full_name}? They won't be able to see your posts or message you.`)) {
        try {
          const { error } = await supabase
            .from('blocked_users')
            .insert({
              blocker_id: user.id,
              blocked_user_id: profile.id
            });
          
          if (error) throw error;
          setIsBlocked(true);
          alert('User blocked');
        } catch (error) {
          console.error('Error blocking:', error);
          alert('Failed to block user');
        }
      }
    }
  };

  const fetchUserPosts = async () => {
    if (!profile?.id) return;
    
    try {
      const { data, error } = await supabase
        .from('posts')
        .select(`
          id,
          content,
          image_url,
          created_at,
          likes_count,
          comments_count
        `)
        .eq('user_id', profile.id)
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      setUserPosts(data || []);
    } catch (error) {
      console.error('Error fetching user posts:', error);
    } finally {
      setPostsLoading(false);
    }
  };

  const checkUsernameChangeStatus = async () => {
    try {
      const { data, error } = await supabase.rpc('days_until_username_change', {
        user_id: user.id
      });

      if (error) throw error;
      
      setDaysUntilUsernameChange(data || 0);
      setCanChangeUsername(data === 0);
    } catch (error) {
      console.error('Error checking username change status:', error);
    }
  };

  const handleSendFriendRequest = async () => {
    if (!profile?.id) return;
    
    try {
      const result = await sendFriendRequest(profile.id);
      if (result.error) {
        setError('Failed to send friend request: ' + result.error.message);
      } else {
        setSuccess('Friend request sent!');
        setFriendshipStatus('pending_sent');
        // Refresh after 2 seconds
        setTimeout(() => {
          setSuccess(null);
          checkFriendshipStatus();
        }, 2000);
      }
    } catch (error) {
      console.error('Error sending friend request:', error);
      setError('Failed to send friend request');
    }
  };

  const handleCancelFriendRequest = async () => {
    if (!profile?.id) return;
    
    try {
      // Find the sent request
      const sentRequests = getSentRequests();
      const request = sentRequests.find(req => req.receiver_id === profile.id);
      
      if (request) {
        const result = await cancelFriendRequest(request.id);
        if (result.error) {
          setError('Failed to cancel friend request');
        } else {
          setSuccess('Friend request cancelled');
          setFriendshipStatus('none');
          setTimeout(() => {
            setSuccess(null);
          }, 2000);
        }
      }
    } catch (error) {
      console.error('Error cancelling friend request:', error);
      setError('Failed to cancel friend request');
    }
  };
  const handleSaveProfile = async () => {
    if (!isOwnProfile) return;
    
    setSaving(true);
    setError(null);
    setSuccess(null);
    
    try {
      // Update profile directly using the profiles table
      const updates: any = {
        full_name: editedProfile.full_name,
        bio: editedProfile.bio,
        location: editedProfile.location,
        website: editedProfile.website,
        avatar_url: editedProfile.avatar_url || null,
        banner_url: editedProfile.banner_url || null,
      };

      // Only update username if it changed and user can change it
      if (editedProfile.username !== profile.username && canChangeUsername) {
        // Clean username
        const cleanUsername = editedProfile.username.toLowerCase().replace(/[^a-z0-9_]/g, '');
        if (cleanUsername.length < 3 || cleanUsername.length > 20) {
          setError('Username must be between 3 and 20 characters');
          setSaving(false);
          return;
        }
        
        // Check if username exists
        const { data: existingUser } = await supabase
          .from('profiles')
          .select('id')
          .eq('username', cleanUsername)
          .neq('id', user.id)
          .single();
          
        if (existingUser) {
          setError('Username is already taken');
          setSaving(false);
          return;
        }
        
        updates.username = cleanUsername;
        updates.last_username_change = new Date().toISOString();
      }

      const { error: updateError } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id);

      if (updateError) throw updateError;

      setSuccess('Profile updated successfully!');
      setIsEditing(false);
      
      // Refresh the page to show updated data
      setTimeout(() => {
        window.location.reload();
      }, 1500);
      
    } catch (error) {
      console.error('Error updating profile:', error);
      setError('Failed to update profile. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleImageUpload = (type: 'avatar' | 'banner') => {
    setUploadingImage(type);
    
    // Create file input
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*';
    fileInput.style.display = 'none';
    document.body.appendChild(fileInput);
    
    fileInput.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) {
        setUploadingImage(null);
        document.body.removeChild(fileInput);
        return;
      }
      
      // Validate file
      if (file.size > 5 * 1024 * 1024) {
        setError('Image size must be less than 5MB');
        setUploadingImage(null);
        document.body.removeChild(fileInput);
        return;
      }
      
      if (!file.type.startsWith('image/')) {
        setError('Please select an image file');
        setUploadingImage(null);
        document.body.removeChild(fileInput);
        return;
      }
      
      try {
        // Convert to base64 for preview
        const reader = new FileReader();
        reader.onload = (event) => {
          const imageUrl = event.target?.result as string;
          
          if (type === 'avatar') {
            setEditedProfile(prev => ({ ...prev, avatar_url: imageUrl }));
          } else {
            setEditedProfile(prev => ({ ...prev, banner_url: imageUrl }));
          }
          
          setUploadingImage(null);
          document.body.removeChild(fileInput);
        };
        
        reader.onerror = () => {
          setError('Failed to read image file');
          setUploadingImage(null);
          document.body.removeChild(fileInput);
        };
        
        reader.readAsDataURL(file);
        
      } catch (error) {
        console.error('Error processing image:', error);
        setError('Failed to process image');
        setUploadingImage(null);
        document.body.removeChild(fileInput);
      }
    };
    
    fileInput.click();
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long'
    });
  };

  // Use actual profile data if available, fallback to passed profile
  const displayProfile = actualProfile || profile;

  // Don't show profile if they blocked me
  if (hasBlockedMe && !isOwnProfile) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <Shield className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">User Not Available</h3>
          <p className="text-gray-600">This user's profile is not accessible.</p>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-2 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
      </div>
    );
  }

  const getFriendActionButton = () => {
    if (isOwnProfile) return null;
    
    switch (friendshipStatus) {
      case 'friends':
        return (
          <div className="flex space-x-2">
            {onStartChat && (
              <button
                onClick={onStartChat}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-medium transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Message</span>
              </button>
            )}
            <button className="flex items-center space-x-2 px-4 py-2 bg-green-100 text-green-700 rounded-lg font-medium">
              <UserCheck className="w-4 h-4" />
              <span>Friends</span>
            </button>
          </div>
        );
      case 'pending_sent':
        return (
          <button
            onClick={handleCancelFriendRequest}
            className="flex items-center space-x-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg font-medium transition-colors"
          >
            <UserX className="w-4 h-4" />
            <span>Cancel Request</span>
          </button>
        );
      case 'pending_received':
        return (
          <button className="flex items-center space-x-2 px-4 py-2 bg-orange-100 text-orange-700 rounded-lg font-medium">
            <Clock className="w-4 h-4" />
            <span>Pending Response</span>
          </button>
        );
      default:
        return (
          <button
            onClick={handleSendFriendRequest}
            className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg font-medium transition-colors"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add Friend</span>
          </button>
        );
    }
  };
  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {/* Banner */}
        <div className="relative h-48 bg-gradient-to-r from-purple-500 to-pink-500">
          {(editedProfile.banner_url || displayProfile.banner_url) && (
            <img
              src={isEditing ? editedProfile.banner_url : displayProfile.banner_url}
              alt="Profile banner"
              className="w-full h-full object-cover"
            />
          )}
          {isOwnProfile && isEditing && (
            <button
              onClick={() => handleImageUpload('banner')}
              disabled={uploadingImage === 'banner'}
              className="absolute top-4 right-4 p-2 bg-black/50 hover:bg-black/70 rounded-full text-white transition-colors disabled:opacity-50"
            >
              {uploadingImage === 'banner' ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <Camera className="w-5 h-5" />
              )}
            </button>
          )}
        </div>

        <div className="px-6 pb-6">
          {/* Profile Picture */}
          <div className="flex items-start justify-between -mt-16 mb-4">
            <div className="relative">
              <div className="w-32 h-32 bg-white rounded-full p-1 shadow-lg">
                <div className="w-full h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center overflow-hidden">
                  {(isEditing ? editedProfile.avatar_url : displayProfile.avatar_url) ? (
                    <img
                      src={isEditing ? editedProfile.avatar_url : displayProfile.avatar_url}
                      alt={displayProfile.full_name}
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    <UserIcon className="w-16 h-16 text-white" />
                  )}
                </div>
              </div>
              {isOwnProfile && isEditing && (
                <button
                  onClick={() => handleImageUpload('avatar')}
                  disabled={uploadingImage === 'avatar'}
                  className="absolute bottom-2 right-2 p-2 bg-white hover:bg-gray-50 rounded-full shadow-lg border border-gray-200 transition-colors disabled:opacity-50"
                >
                  {uploadingImage === 'avatar' ? (
                    <div className="w-4 h-4 border-2 border-gray-600/30 border-t-gray-600 rounded-full animate-spin" />
                  ) : (
                    <Camera className="w-4 h-4 text-gray-600" />
                  )}
                </button>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-2 mt-16">
              {isOwnProfile ? (
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className="flex items-center space-x-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium transition-colors"
                >
                  {isEditing ? <X className="w-4 h-4" /> : <Edit3 className="w-4 h-4" />}
                  <span>{isEditing ? 'Cancel' : 'Edit Profile'}</span>
                </button>
              ) : !isBlocked ? (
                <div className="flex space-x-2">
                  {getFriendActionButton()}
                  <button
                    onClick={handleBlock}
                    className="flex items-center space-x-2 px-4 py-2 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg font-medium transition-colors"
                  >
                    <Shield className="w-4 h-4" />
                    <span>Block</span>
                  </button>
                </div>
              ) : (
                <div className="flex space-x-2">
                  <button
                    onClick={handleBlock}
                    className="flex items-center space-x-2 px-4 py-2 bg-green-100 hover:bg-green-200 text-green-700 rounded-lg font-medium transition-colors"
                  >
                    <ShieldOff className="w-4 h-4" />
                    <span>Unblock</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Error/Success Messages */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center space-x-2">
              <AlertCircle className="w-5 h-5 text-red-500" />
              <span className="text-red-700">{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg flex items-center space-x-2">
              <Save className="w-5 h-5 text-green-500" />
              <span className="text-green-700">{success}</span>
            </div>
          )}

          {/* Profile Info */}
          {isEditing ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input
                  type="text"
                  value={editedProfile.full_name}
                  onChange={(e) => setEditedProfile(prev => ({ ...prev, full_name: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Username
                  {!canChangeUsername && (
                    <span className="text-xs text-orange-600 ml-2">
                      <Clock className="w-3 h-3 inline mr-1" />
                      Can change in {daysUntilUsernameChange} days
                    </span>
                  )}
                </label>
                <input
                  type="text"
                  value={editedProfile.username}
                  onChange={(e) => setEditedProfile(prev => ({ ...prev, username: e.target.value }))}
                  disabled={!canChangeUsername}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent ${
                    !canChangeUsername ? 'bg-gray-100 cursor-not-allowed' : ''
                  }`}
                />
                {!canChangeUsername && (
                  <p className="text-xs text-gray-500 mt-1">
                    Username can only be changed once every 7 days
                  </p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
                <textarea
                  value={editedProfile.bio}
                  onChange={(e) => setEditedProfile(prev => ({ ...prev, bio: e.target.value }))}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Tell us about yourself..."
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                <input
                  type="text"
                  value={editedProfile.location}
                  onChange={(e) => setEditedProfile(prev => ({ ...prev, location: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Where are you located?"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Website</label>
                <input
                  type="url"
                  value={editedProfile.website}
                  onChange={(e) => setEditedProfile(prev => ({ ...prev, website: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="https://your-website.com"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Avatar URL</label>
                  <div className="flex space-x-2">
                    <input
                      type="url"
                      value={editedProfile.avatar_url}
                      onChange={(e) => setEditedProfile(prev => ({ ...prev, avatar_url: e.target.value }))}
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="https://example.com/avatar.jpg"
                    />
                    <button
                      type="button"
                      onClick={() => handleImageUpload('avatar')}
                      disabled={uploadingImage === 'avatar'}
                      className="px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors disabled:opacity-50"
                    >
                      {uploadingImage === 'avatar' ? (
                        <div className="w-4 h-4 border-2 border-gray-600/30 border-t-gray-600 rounded-full animate-spin" />
                      ) : (
                        <Upload className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Banner URL</label>
                  <div className="flex space-x-2">
                    <input
                      type="url"
                      value={editedProfile.banner_url}
                      onChange={(e) => setEditedProfile(prev => ({ ...prev, banner_url: e.target.value }))}
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="https://example.com/banner.jpg"
                    />
                    <button
                      type="button"
                      onClick={() => handleImageUpload('banner')}
                      disabled={uploadingImage === 'banner'}
                      className="px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors disabled:opacity-50"
                    >
                      {uploadingImage === 'banner' ? (
                        <div className="w-4 h-4 border-2 border-gray-600/30 border-t-gray-600 rounded-full animate-spin" />
                      ) : (
                        <Upload className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <button
                  onClick={handleSaveProfile}
                  disabled={saving}
                  className="flex items-center space-x-2 px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg font-medium transition-colors disabled:opacity-50"
                >
                  {saving ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <Save className="w-4 h-4" />
                  )}
                  <span>Save Changes</span>
                </button>
              </div>
              
              {/* Blocked Users Button for own profile */}
              <div className="mt-4">
                <button
                  onClick={() => setShowBlockedUsers(true)}
                  className="flex items-center space-x-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg font-medium transition-colors"
                >
                  <Shield className="w-4 h-4" />
                  <span>Blocked Users</span>
                </button>
              </div>
            </div>
          ) : (
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-1">{displayProfile.full_name}</h1>
              <p className="text-gray-600 mb-3">@{displayProfile.username}</p>
              
              {displayProfile.bio && (
                <p className="text-gray-700 mb-4">{displayProfile.bio}</p>
              )}

              <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                {displayProfile.location && (
                  <div className="flex items-center space-x-1">
                    <MapPin className="w-4 h-4" />
                    <span>{displayProfile.location}</span>
                  </div>
                )}
                {displayProfile.website && (
                  <div className="flex items-center space-x-1">
                    <LinkIcon className="w-4 h-4" />
                    <a 
                      href={displayProfile.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-500 hover:underline"
                    >
                      {displayProfile.website.replace(/^https?:\/\//, '')}
                    </a>
                  </div>
                )}
                <div className="flex items-center space-x-1">
                  <Calendar className="w-4 h-4" />
                  <span>Joined {formatDate(displayProfile.created_at)}</span>
                </div>
              </div>

              {/* Stats */}
              <div className="flex items-center space-x-6 mt-4 pt-4 border-t border-gray-100">
                <div className="text-center">
                  <div className="text-xl font-bold text-gray-900">{displayProfile.posts_count || 0}</div>
                  <div className="text-sm text-gray-500">Posts</div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold text-purple-600">{displayProfile.friends_count || 0}</div>
                  <div className="text-sm text-gray-500">Friends</div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold text-pink-600">{displayProfile.followers_count || 0}</div>
                  <div className="text-sm text-gray-500">Followers</div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold text-blue-600">{displayProfile.following_count || 0}</div>
                  <div className="text-sm text-gray-500">Following</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* User Posts */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          {isOwnProfile ? 'Your Posts' : `${displayProfile.full_name}'s Posts`}
        </h2>
        
        {postsLoading ? (
          <div className="flex items-center justify-center py-8">
            <div className="w-6 h-6 border-2 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
          </div>
        ) : userPosts.length > 0 ? (
          <div className="space-y-4">
            {userPosts.map((post) => (
              <div key={post.id} className="border border-gray-200 rounded-lg p-4">
                <p className="text-gray-900 mb-2">{post.content}</p>
                {post.image_url && (
                  <img
                    src={post.image_url}
                    alt="Post image"
                    className="w-full max-w-md rounded-lg mb-2"
                  />
                )}
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>{new Date(post.created_at).toLocaleDateString()}</span>
                  <div className="flex space-x-4">
                    <span>{post.likes_count} likes</span>
                    <span>{post.comments_count} comments</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <UserIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">
              {isOwnProfile ? "You haven't posted anything yet." : `${displayProfile.full_name} hasn't posted anything yet.`}
            </p>
          </div>
        )}
      </div>
      
      {/* Blocked Users Modal */}
      {showBlockedUsers && (
        <BlockedUsers
          user={user}
          onClose={() => setShowBlockedUsers(false)}
        />
      )}
    </div>
  );
}