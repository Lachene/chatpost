import React from 'react';
import { User } from '@supabase/supabase-js';
import { useSocial } from '../hooks/useSocial';
import { User as UserIcon, Check, X, Users } from 'lucide-react';

interface FriendRequestNotificationsProps {
  user: User;
}

export function FriendRequestNotifications({ user }: FriendRequestNotificationsProps) {
  const { getPendingRequests, getSentRequests, respondToFriendRequest, cancelFriendRequest } = useSocial(user);
  const pendingRequests = getPendingRequests();
  const sentRequests = getSentRequests();

  if (pendingRequests.length === 0 && sentRequests.length === 0) return null;

  const handleAccept = async (requestId: string) => {
    const result = await respondToFriendRequest(requestId, 'accepted');
    if (result.error) {
      alert('Failed to accept friend request: ' + result.error.message);
    } else {
      alert('Friend request accepted! You are now friends.');
      // Force refresh to update friend counts
      window.location.reload();
    }
  };

  const handleReject = async (requestId: string) => {
    const result = await respondToFriendRequest(requestId, 'rejected');
    if (result.error) {
      alert('Failed to reject friend request: ' + result.error.message);
    } else {
      alert('Friend request declined.');
      window.location.reload();
    }
  };

  const handleCancel = async (requestId: string) => {
    const result = await cancelFriendRequest(requestId);
    if (result.error) {
      alert('Failed to cancel friend request: ' + result.error.message);
    } else {
      alert('Friend request cancelled.');
      window.location.reload();
    }
  };

  return (
    <div className="space-y-6 mb-8">
      {/* Incoming Friend Requests */}
      {pendingRequests.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center">
              <Users className="w-4 h-4 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">
              Friend Requests ({pendingRequests.length})
            </h3>
          </div>

          <div className="space-y-3">
            {pendingRequests.map((request) => (
              <div key={request.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                    {request.sender_profile?.avatar_url ? (
                      <img
                        src={request.sender_profile.avatar_url}
                        alt={request.sender_profile.full_name}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                    ) : (
                      <UserIcon className="w-5 h-5 text-white" />
                    )}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">
                      {request.sender_profile?.full_name || 'Unknown User'}
                    </p>
                    <p className="text-sm text-gray-500">
                      @{request.sender_profile?.username} wants to be friends
                    </p>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <button
                    onClick={() => handleAccept(request.id)}
                    className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-1"
                  >
                    <Check className="w-4 h-4" />
                    <span>Accept</span>
                  </button>
                  <button
                    onClick={() => handleReject(request.id)}
                    className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-1"
                  >
                    <X className="w-4 h-4" />
                    <span>Decline</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sent Friend Requests */}
      {sentRequests.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-8 h-8 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center">
              <Users className="w-4 h-4 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">
              Sent Requests ({sentRequests.length})
            </h3>
          </div>

          <div className="space-y-3">
            {sentRequests.map((request) => (
              <div key={request.id} className="flex items-center justify-between p-4 bg-yellow-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                    {request.receiver_profile?.avatar_url ? (
                      <img
                        src={request.receiver_profile.avatar_url}
                        alt={request.receiver_profile.full_name}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                    ) : (
                      <UserIcon className="w-5 h-5 text-white" />
                    )}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">
                      {request.receiver_profile?.full_name || 'Unknown User'}
                    </p>
                    <p className="text-sm text-gray-500">
                      Friend request sent to @{request.receiver_profile?.username}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => handleCancel(request.id)}
                  className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-1"
                >
                  <X className="w-4 h-4" />
                  <span>Cancel</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}