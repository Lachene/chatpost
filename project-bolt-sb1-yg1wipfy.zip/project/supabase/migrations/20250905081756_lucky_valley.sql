/*
# Fix User Post Isolation

This migration ensures that:
1. Each user only sees their own posts
2. Fixes the foreign key relationship error
3. Proper user isolation for posts

*/

-- Ensure posts table has proper foreign key constraint
ALTER TABLE posts 
DROP CONSTRAINT IF EXISTS posts_user_id_fkey;

ALTER TABLE posts 
ADD CONSTRAINT posts_user_id_fkey 
FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- Update posts policies to ensure users only see their own posts
DROP POLICY IF EXISTS "Posts are publicly readable" ON posts;
CREATE POLICY "Users can read own posts"
  ON posts FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Ensure users can only insert their own posts
DROP POLICY IF EXISTS "Users can insert own posts" ON posts;
CREATE POLICY "Users can insert own posts"
  ON posts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Ensure users can only update their own posts
DROP POLICY IF EXISTS "Users can update own posts" ON posts;
CREATE POLICY "Users can update own posts"
  ON posts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Ensure users can only delete their own posts
DROP POLICY IF EXISTS "Users can delete own posts" ON posts;
CREATE POLICY "Users can delete own posts"
  ON posts FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Update likes policies to ensure users can only see likes on their own posts
DROP POLICY IF EXISTS "Likes are publicly readable" ON likes;
CREATE POLICY "Users can read likes on own posts"
  ON likes FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM posts 
      WHERE posts.id = likes.post_id 
      AND posts.user_id = auth.uid()
    )
    OR likes.user_id = auth.uid()
  );

-- Update comments policies to ensure users can only see comments on their own posts
DROP POLICY IF EXISTS "Comments are publicly readable" ON comments;
CREATE POLICY "Users can read comments on own posts"
  ON comments FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM posts 
      WHERE posts.id = comments.post_id 
      AND posts.user_id = auth.uid()
    )
    OR comments.user_id = auth.uid()
  );

-- Refresh the schema cache
NOTIFY pgrst, 'reload schema';