/*
# Make Posts Public Like Instagram/Threads

This migration changes the app to work like Instagram/Threads where:
1. All users can see posts from all other users
2. Users can still only edit/delete their own posts
3. Proper social media experience

*/

-- Update posts policies to make posts publicly readable
DROP POLICY IF EXISTS "Users can read own posts" ON posts;
CREATE POLICY "Posts are publicly readable"
  ON posts FOR SELECT
  TO authenticated
  USING (true);

-- Keep other policies the same (users can only modify their own posts)
-- Users can insert own posts - already exists
-- Users can update own posts - already exists  
-- Users can delete own posts - already exists

-- Update likes policies to allow users to see all likes
DROP POLICY IF EXISTS "Users can read likes on own posts" ON likes;
CREATE POLICY "Likes are publicly readable"
  ON likes FOR SELECT
  TO authenticated
  USING (true);

-- Update comments policies to allow users to see all comments
DROP POLICY IF EXISTS "Users can read comments on own posts" ON comments;
CREATE POLICY "Comments are publicly readable"
  ON comments FOR SELECT
  TO authenticated
  USING (true);

-- Refresh the schema cache
NOTIFY pgrst, 'reload schema';