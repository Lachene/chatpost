/*
# Fix Social System - Chat, Friends, and Notifications

This migration fixes:
1. Friend count not updating when requests are accepted
2. Follower counts not updating properly
3. Chat and call functionality for friends
4. Notification system improvements
*/

-- First, let's check and fix the friend request acceptance flow
CREATE OR REPLACE FUNCTION public.update_friends_count()
RETURNS TRIGGER AS $$
BEGIN
  RAISE LOG 'Friend count trigger fired: %, %, %', TG_OP, OLD.status, NEW.status;
  
  IF TG_OP = 'INSERT' AND NEW.status = 'accepted' THEN
    -- Increment friends count for both users
    UPDATE public.profiles SET friends_count = GREATEST(friends_count + 1, 0) WHERE id = NEW.sender_id;
    UPDATE public.profiles SET friends_count = GREATEST(friends_count + 1, 0) WHERE id = NEW.receiver_id;
    RAISE LOG 'Friendship created: % and %, friends count incremented', NEW.sender_id, NEW.receiver_id;
    RETURN NEW;
    
  ELSIF TG_OP = 'UPDATE' THEN
    RAISE LOG 'Friend request status change: % -> %', OLD.status, NEW.status;
    
    IF OLD.status != 'accepted' AND NEW.status = 'accepted' THEN
      -- Friend request accepted - increment both users' friend counts
      UPDATE public.profiles SET friends_count = GREATEST(friends_count + 1, 0) WHERE id = NEW.sender_id;
      UPDATE public.profiles SET friends_count = GREATEST(friends_count + 1, 0) WHERE id = NEW.receiver_id;
      RAISE LOG 'Friend request accepted: % and %, friends count incremented', NEW.sender_id, NEW.receiver_id;
      
    ELSIF OLD.status = 'accepted' AND NEW.status != 'accepted' THEN
      -- Friendship ended - decrement both users' friend counts
      UPDATE public.profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = NEW.sender_id;
      UPDATE public.profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = NEW.receiver_id;
      RAISE LOG 'Friendship ended: % and %, friends count decremented', NEW.sender_id, NEW.receiver_id;
    END IF;
    RETURN NEW;
    
  ELSIF TG_OP = 'DELETE' AND OLD.status = 'accepted' THEN
    -- Friendship deleted - decrement both users' friend counts
    UPDATE public.profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = OLD.sender_id;
    UPDATE public.profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = OLD.receiver_id;
    RAISE LOG 'Friendship deleted: % and %, friends count decremented', OLD.sender_id, OLD.receiver_id;
    RETURN OLD;
  END IF;
  
  RETURN COALESCE(NEW, OLD);
EXCEPTION WHEN OTHERS THEN
  RAISE WARNING 'Error in update_friends_count: %', SQLERRM;
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate the follow count function with better logging
CREATE OR REPLACE FUNCTION public.update_follow_counts()
RETURNS TRIGGER AS $$
BEGIN
  RAISE LOG 'Follow count trigger fired: %', TG_OP;
  
  IF TG_OP = 'INSERT' THEN
    -- Increment following count for follower
    UPDATE public.profiles 
    SET following_count = GREATEST(following_count + 1, 0)
    WHERE id = NEW.follower_id;
    
    -- Increment followers count for the person being followed
    UPDATE public.profiles 
    SET followers_count = GREATEST(followers_count + 1, 0)
    WHERE id = NEW.following_id;
    
    RAISE LOG 'Follow added: % following %, counts updated', NEW.follower_id, NEW.following_id;
    RETURN NEW;
    
  ELSIF TG_OP = 'DELETE' THEN
    -- Decrement following count for follower
    UPDATE public.profiles 
    SET following_count = GREATEST(following_count - 1, 0)
    WHERE id = OLD.follower_id;
    
    -- Decrement followers count for the person being unfollowed
    UPDATE public.profiles 
    SET followers_count = GREATEST(followers_count - 1, 0)
    WHERE id = OLD.following_id;
    
    RAISE LOG 'Follow removed: % unfollowed %, counts updated', OLD.follower_id, OLD.following_id;
    RETURN OLD;
  END IF;
  
  RETURN NULL;
EXCEPTION WHEN OTHERS THEN
  RAISE WARNING 'Error in update_follow_counts: %', SQLERRM;
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a messages table for chat functionality
CREATE TABLE IF NOT EXISTS public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  receiver_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  content text NOT NULL,
  message_type text DEFAULT 'text' CHECK (message_type IN ('text', 'image', 'file')),
  read_at timestamptz,
  created_at timestamptz DEFAULT now(),
  CHECK (sender_id != receiver_id)
);

-- Create a calls table for call history
CREATE TABLE IF NOT EXISTS public.calls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  caller_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  receiver_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  call_type text DEFAULT 'voice' CHECK (call_type IN ('voice', 'video')),
  status text DEFAULT 'initiated' CHECK (status IN ('initiated', 'answered', 'missed', 'ended')),
  duration_seconds integer DEFAULT 0,
  started_at timestamptz DEFAULT now(),
  ended_at timestamptz,
  CHECK (caller_id != receiver_id)
);

-- Enable RLS on new tables
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.calls ENABLE ROW LEVEL SECURITY;

-- Messages policies - only friends can message each other
CREATE POLICY "Users can read their messages"
  ON public.messages FOR SELECT
  TO authenticated
  USING (
    auth.uid() = sender_id OR auth.uid() = receiver_id
  );

CREATE POLICY "Friends can send messages"
  ON public.messages FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = sender_id AND
    EXISTS (
      SELECT 1 FROM public.friend_requests
      WHERE ((sender_id = auth.uid() AND receiver_id = messages.receiver_id) OR
             (receiver_id = auth.uid() AND sender_id = messages.receiver_id))
      AND status = 'accepted'
    )
  );

CREATE POLICY "Users can update their sent messages"
  ON public.messages FOR UPDATE
  TO authenticated
  USING (auth.uid() = sender_id)
  WITH CHECK (auth.uid() = sender_id);

-- Calls policies - only friends can call each other
CREATE POLICY "Users can read their calls"
  ON public.calls FOR SELECT
  TO authenticated
  USING (
    auth.uid() = caller_id OR auth.uid() = receiver_id
  );

CREATE POLICY "Friends can initiate calls"
  ON public.calls FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = caller_id AND
    EXISTS (
      SELECT 1 FROM public.friend_requests
      WHERE ((sender_id = auth.uid() AND receiver_id = calls.receiver_id) OR
             (receiver_id = auth.uid() AND sender_id = calls.receiver_id))
      AND status = 'accepted'
    )
  );

CREATE POLICY "Users can update their calls"
  ON public.calls FOR UPDATE
  TO authenticated
  USING (auth.uid() = caller_id OR auth.uid() = receiver_id)
  WITH CHECK (auth.uid() = caller_id OR auth.uid() = receiver_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON public.messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_receiver_id ON public.messages(receiver_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON public.messages(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_calls_caller_id ON public.calls(caller_id);
CREATE INDEX IF NOT EXISTS idx_calls_receiver_id ON public.calls(receiver_id);
CREATE INDEX IF NOT EXISTS idx_calls_created_at ON public.calls(started_at DESC);

-- Grant permissions
GRANT ALL ON public.messages TO authenticated;
GRANT ALL ON public.calls TO authenticated;

-- Fix any existing count discrepancies by recalculating everything
UPDATE public.profiles 
SET followers_count = COALESCE((
  SELECT COUNT(*) 
  FROM public.follows 
  WHERE follows.following_id = profiles.id
), 0);

UPDATE public.profiles 
SET following_count = COALESCE((
  SELECT COUNT(*) 
  FROM public.follows 
  WHERE follows.follower_id = profiles.id
), 0);

UPDATE public.profiles 
SET friends_count = COALESCE((
  SELECT COUNT(*) 
  FROM public.friend_requests 
  WHERE (friend_requests.sender_id = profiles.id OR friend_requests.receiver_id = profiles.id)
  AND friend_requests.status = 'accepted'
), 0);

UPDATE public.profiles 
SET posts_count = COALESCE((
  SELECT COUNT(*) 
  FROM public.posts 
  WHERE posts.user_id = profiles.id
), 0);

-- Refresh the schema cache
NOTIFY pgrst, 'reload schema';

-- Test that everything is working
DO $$
DECLARE
  test_count integer;
BEGIN
  -- Test friend requests table
  SELECT COUNT(*) INTO test_count FROM public.friend_requests WHERE status = 'accepted';
  RAISE NOTICE '✅ Found % accepted friendships', test_count;
  
  -- Test follows table
  SELECT COUNT(*) INTO test_count FROM public.follows;
  RAISE NOTICE '✅ Found % follow relationships', test_count;
  
  -- Test messages table
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'messages' AND table_schema = 'public') THEN
    RAISE NOTICE '✅ Messages table created successfully';
  END IF;
  
  -- Test calls table
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'calls' AND table_schema = 'public') THEN
    RAISE NOTICE '✅ Calls table created successfully';
  END IF;
  
  RAISE NOTICE '🚀 Social system is fully configured and ready!';
END $$;