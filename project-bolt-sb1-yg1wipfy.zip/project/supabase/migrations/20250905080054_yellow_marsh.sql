/*
# Fix User Creation Database Issues

1. Database Setup
   - Ensure profiles table exists with correct structure
   - Fix user creation trigger
   - Add proper error handling

2. Security
   - Proper RLS policies for profile creation
   - Handle edge cases in user registration

3. Features
   - Automatic profile creation for new users
   - Unique username generation
   - Proper error handling
*/

-- Ensure profiles table exists with correct structure
CREATE TABLE IF NOT EXISTS profiles (
  id uuid REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  username text UNIQUE NOT NULL,
  full_name text NOT NULL DEFAULT '',
  bio text DEFAULT '',
  avatar_url text,
  followers_count integer DEFAULT 0,
  following_count integer DEFAULT 0,
  posts_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS if not already enabled
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to recreate them
DROP POLICY IF EXISTS "Profiles are publicly readable" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;

-- Recreate policies
CREATE POLICY "Profiles are publicly readable"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Improved function to handle new user creation with better error handling
CREATE OR REPLACE FUNCTION handle_new_user() 
RETURNS TRIGGER AS $$
DECLARE
  username_attempt text;
  attempt_count integer := 0;
  max_attempts integer := 5;
BEGIN
  -- Start with username from metadata or generate one
  username_attempt := COALESCE(
    NEW.raw_user_meta_data->>'username',
    'user_' || substr(NEW.id::text, 1, 8)
  );
  
  -- Clean username (lowercase, alphanumeric and underscore only)
  username_attempt := lower(regexp_replace(username_attempt, '[^a-zA-Z0-9_]', '', 'g'));
  
  -- Ensure username is not empty
  IF username_attempt = '' OR username_attempt IS NULL THEN
    username_attempt := 'user_' || substr(NEW.id::text, 1, 8);
  END IF;
  
  -- Try to insert profile with unique username
  WHILE attempt_count < max_attempts LOOP
    BEGIN
      INSERT INTO profiles (id, username, full_name)
      VALUES (
        NEW.id,
        username_attempt,
        COALESCE(NEW.raw_user_meta_data->>'full_name', '')
      );
      
      -- If successful, exit the loop
      EXIT;
      
    EXCEPTION WHEN unique_violation THEN
      -- If username already exists, try with a suffix
      attempt_count := attempt_count + 1;
      username_attempt := COALESCE(
        NEW.raw_user_meta_data->>'username',
        'user_' || substr(NEW.id::text, 1, 8)
      ) || '_' || attempt_count;
      
      -- Clean the new username attempt
      username_attempt := lower(regexp_replace(username_attempt, '[^a-zA-Z0-9_]', '', 'g'));
      
      -- If we've reached max attempts, use a timestamp-based username
      IF attempt_count >= max_attempts THEN
        username_attempt := 'user_' || substr(NEW.id::text, 1, 8) || '_' || extract(epoch from now())::bigint;
        
        INSERT INTO profiles (id, username, full_name)
        VALUES (
          NEW.id,
          username_attempt,
          COALESCE(NEW.raw_user_meta_data->>'full_name', '')
        );
        EXIT;
      END IF;
    END;
  END LOOP;
  
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Log the error but don't prevent user creation
  RAISE WARNING 'Failed to create profile for user %: %', NEW.id, SQLERRM;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop and recreate the trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_profiles_username ON profiles(username);
CREATE INDEX IF NOT EXISTS idx_profiles_id ON profiles(id);