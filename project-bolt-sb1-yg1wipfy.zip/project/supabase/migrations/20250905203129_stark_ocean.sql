/*
# Fix message_type Database Error

This migration completely removes all references to message_type field that's causing the insert error.

1. Database Cleanup
   - Drop all triggers that reference message_type
   - Drop all functions that reference message_type  
   - Ensure messages table has correct structure
   - Remove any remaining message_type references

2. Security
   - Recreate clean RLS policies
   - Grant proper permissions
*/

-- Drop ALL triggers and functions that might reference message_type
DROP TRIGGER IF EXISTS update_message_status_trigger ON public.messages CASCADE;
DROP TRIGGER IF EXISTS auto_deliver_messages_trigger ON public.messages CASCADE;
DROP TRIGGER IF EXISTS message_insert_trigger ON public.messages CASCADE;
DROP TRIGGER IF EXISTS message_update_trigger ON public.messages CASCADE;
DROP TRIGGER IF EXISTS notify_message_trigger ON public.messages CASCADE;

DROP FUNCTION IF EXISTS public.update_message_status() CASCADE;
DROP FUNCTION IF EXISTS public.auto_deliver_messages() CASCADE;
DROP FUNCTION IF EXISTS public.handle_message_insert() CASCADE;
DROP FUNCTION IF EXISTS public.handle_message_update() CASCADE;
DROP FUNCTION IF EXISTS public.notify_message_participants() CASCADE;

-- Ensure messages table structure is clean
ALTER TABLE public.messages 
DROP COLUMN IF EXISTS message_type CASCADE,
DROP COLUMN IF EXISTS file_url CASCADE,
DROP COLUMN IF EXISTS file_name CASCADE,
DROP COLUMN IF EXISTS file_size CASCADE,
DROP COLUMN IF EXISTS reply_to_id CASCADE,
DROP COLUMN IF EXISTS delivered_at CASCADE,
DROP COLUMN IF EXISTS read_at CASCADE;

-- Ensure required columns exist with proper defaults
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'messages' AND column_name = 'status'
  ) THEN
    ALTER TABLE public.messages ADD COLUMN status text DEFAULT 'sent';
  END IF;
END $$;

-- Set proper constraints
ALTER TABLE public.messages 
ALTER COLUMN content SET NOT NULL,
ALTER COLUMN status SET DEFAULT 'sent',
ALTER COLUMN created_at SET DEFAULT now();

-- Drop and recreate ALL RLS policies to ensure they're clean
DROP POLICY IF EXISTS "Users can read their messages" ON public.messages;
DROP POLICY IF EXISTS "Friends can send messages" ON public.messages;
DROP POLICY IF EXISTS "Users can update message status" ON public.messages;
DROP POLICY IF EXISTS "Users can insert messages" ON public.messages;
DROP POLICY IF EXISTS "Users can update their messages" ON public.messages;

-- Create simple, clean policies
CREATE POLICY "Users can read their messages"
  ON public.messages FOR SELECT
  TO authenticated
  USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can insert messages"
  ON public.messages FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = sender_id);

-- Grant permissions
GRANT ALL ON public.messages TO authenticated;

-- Clean up any invalid data
DELETE FROM public.messages WHERE sender_id IS NULL OR receiver_id IS NULL OR content IS NULL;

-- Test that a message can be inserted without errors
DO $$
DECLARE
  test_user_id uuid;
  test_message_id uuid;
BEGIN
  -- Get first user for testing
  SELECT id INTO test_user_id FROM auth.users LIMIT 1;
  
  IF test_user_id IS NOT NULL THEN
    -- Try to insert a test message (will be deleted immediately)
    INSERT INTO public.messages (sender_id, receiver_id, content, status)
    VALUES (test_user_id, test_user_id, 'test message', 'sent')
    RETURNING id INTO test_message_id;
    
    -- Delete the test message
    DELETE FROM public.messages WHERE id = test_message_id;
    
    RAISE NOTICE '✅ Message insertion test PASSED';
  ELSE
    RAISE NOTICE '⚠️ No users found for testing';
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE '❌ Message insertion test FAILED: %', SQLERRM;
END $$;