/*
# Add Social Features: Profiles, Followers, Following, and Friend Requests

1. New Tables
   - `friend_requests` - Friend request system
     - `id` (uuid, primary key)
     - `sender_id` (uuid, references auth.users)
     - `receiver_id` (uuid, references auth.users)
     - `status` (enum: pending, accepted, rejected)
     - `created_at` (timestamp)
     - `updated_at` (timestamp)

2. Updates to existing tables
   - Add `friends_count` to profiles table
   - Update follow system to work with friend requests

3. Security
   - Enable RLS on friend_requests table
   - Users can manage their own friend requests
   - Proper policies for social interactions

4. Features
   - Send/accept/reject friend requests
   - Follow/unfollow users
   - View user profiles
   - Friend and follower counts
*/

-- Add friends_count to profiles table
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS friends_count integer DEFAULT 0;

-- Create friend_requests table
CREATE TABLE IF NOT EXISTS friend_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  receiver_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(sender_id, receiver_id),
  CHECK (sender_id != receiver_id)
);

-- Enable RLS on friend_requests
ALTER TABLE friend_requests ENABLE ROW LEVEL SECURITY;

-- Friend requests policies
CREATE POLICY "Users can read their friend requests"
  ON friend_requests FOR SELECT
  TO authenticated
  USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can send friend requests"
  ON friend_requests FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = sender_id);

CREATE POLICY "Users can update received friend requests"
  ON friend_requests FOR UPDATE
  TO authenticated
  USING (auth.uid() = receiver_id)
  WITH CHECK (auth.uid() = receiver_id);

CREATE POLICY "Users can delete their sent friend requests"
  ON friend_requests FOR DELETE
  TO authenticated
  USING (auth.uid() = sender_id);

-- Function to update friends count
CREATE OR REPLACE FUNCTION update_friends_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' AND NEW.status = 'accepted' THEN
    -- Increment friends count for both users
    UPDATE profiles SET friends_count = friends_count + 1 WHERE id = NEW.sender_id;
    UPDATE profiles SET friends_count = friends_count + 1 WHERE id = NEW.receiver_id;
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    IF OLD.status != 'accepted' AND NEW.status = 'accepted' THEN
      -- Friend request accepted
      UPDATE profiles SET friends_count = friends_count + 1 WHERE id = NEW.sender_id;
      UPDATE profiles SET friends_count = friends_count + 1 WHERE id = NEW.receiver_id;
    ELSIF OLD.status = 'accepted' AND NEW.status != 'accepted' THEN
      -- Friendship ended
      UPDATE profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = NEW.sender_id;
      UPDATE profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = NEW.receiver_id;
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' AND OLD.status = 'accepted' THEN
    -- Friendship deleted
    UPDATE profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = OLD.sender_id;
    UPDATE profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = OLD.receiver_id;
    RETURN OLD;
  END IF;
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for friends count updates
DROP TRIGGER IF EXISTS update_friends_count_trigger ON friend_requests;
CREATE TRIGGER update_friends_count_trigger
  AFTER INSERT OR UPDATE OR DELETE ON friend_requests
  FOR EACH ROW EXECUTE FUNCTION update_friends_count();

-- Function to update updated_at timestamp for friend requests
CREATE OR REPLACE FUNCTION update_friend_request_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for friend_requests updated_at
DROP TRIGGER IF EXISTS update_friend_requests_updated_at ON friend_requests;
CREATE TRIGGER update_friend_requests_updated_at
  BEFORE UPDATE ON friend_requests
  FOR EACH ROW EXECUTE FUNCTION update_friend_request_updated_at();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_friend_requests_sender_id ON friend_requests(sender_id);
CREATE INDEX IF NOT EXISTS idx_friend_requests_receiver_id ON friend_requests(receiver_id);
CREATE INDEX IF NOT EXISTS idx_friend_requests_status ON friend_requests(status);

-- Fix any existing friends count discrepancies
UPDATE profiles 
SET friends_count = (
  SELECT COUNT(*) 
  FROM friend_requests 
  WHERE (friend_requests.sender_id = profiles.id OR friend_requests.receiver_id = profiles.id)
  AND friend_requests.status = 'accepted'
);