@@ .. @@
 GRANT EXECUTE ON FUNCTION public.toggle_post_reaction(uuid, text) TO authenticated;
 GRANT EXECUTE ON FUNCTION public.share_post(uuid) TO authenticated;
 
--- Optimize database for performance
-VACUUM ANALYZE public.posts;
-VACUUM ANALYZE public.profiles;
-VACUUM ANALYZE public.post_reactions;
-VACUUM ANALYZE public.post_shares;
-VACUUM ANALYZE public.messages;
-
 -- Success message