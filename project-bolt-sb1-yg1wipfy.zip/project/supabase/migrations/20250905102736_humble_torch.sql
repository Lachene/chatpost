/*
# Fix Foreign Key Constraints for Friend Requests

This migration fixes the missing foreign key relationships between 
friend_requests and profiles tables that PostgREST needs for embedding.

The issue: PostgREST cannot find relationships with the expected names:
- friend_requests_sender_id_fkey
- friend_requests_receiver_id_fkey

This prevents embedding profile data in friend_requests queries.
*/

-- 1) Ensure column types match (they should already be uuid)
-- This is just a safety check - no changes needed if types already match
DO $$
BEGIN
  -- Check if sender_id is already uuid type
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'friend_requests' 
    AND column_name = 'sender_id' 
    AND data_type = 'uuid'
  ) THEN
    ALTER TABLE public.friend_requests 
    ALTER COLUMN sender_id TYPE uuid USING sender_id::uuid;
  END IF;
  
  -- Check if receiver_id is already uuid type
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'friend_requests' 
    AND column_name = 'receiver_id' 
    AND data_type = 'uuid'
  ) THEN
    ALTER TABLE public.friend_requests 
    ALTER COLUMN receiver_id TYPE uuid USING receiver_id::uuid;
  END IF;
END $$;

-- 2) Drop any existing foreign key constraints that might have wrong names
DO $$
BEGIN
  -- Drop sender_id foreign key if it exists with the expected name
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE table_schema = 'public' 
    AND table_name = 'friend_requests'
    AND constraint_name = 'friend_requests_sender_id_fkey'
  ) THEN
    ALTER TABLE public.friend_requests
      DROP CONSTRAINT friend_requests_sender_id_fkey;
  END IF;

  -- Drop receiver_id foreign key if it exists with the expected name
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE table_schema = 'public' 
    AND table_name = 'friend_requests'
    AND constraint_name = 'friend_requests_receiver_id_fkey'
  ) THEN
    ALTER TABLE public.friend_requests
      DROP CONSTRAINT friend_requests_receiver_id_fkey;
  END IF;
  
  -- Also drop any other foreign key constraints on these columns
  -- that might exist with different names
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints tc
    JOIN information_schema.key_column_usage kcu 
      ON tc.constraint_name = kcu.constraint_name
    WHERE tc.table_schema = 'public' 
    AND tc.table_name = 'friend_requests'
    AND tc.constraint_type = 'FOREIGN KEY'
    AND kcu.column_name = 'sender_id'
    AND tc.constraint_name != 'friend_requests_sender_id_fkey'
  ) THEN
    -- Get the constraint name and drop it
    DECLARE
      constraint_name_to_drop text;
    BEGIN
      SELECT tc.constraint_name INTO constraint_name_to_drop
      FROM information_schema.table_constraints tc
      JOIN information_schema.key_column_usage kcu 
        ON tc.constraint_name = kcu.constraint_name
      WHERE tc.table_schema = 'public' 
      AND tc.table_name = 'friend_requests'
      AND tc.constraint_type = 'FOREIGN KEY'
      AND kcu.column_name = 'sender_id'
      AND tc.constraint_name != 'friend_requests_sender_id_fkey'
      LIMIT 1;
      
      IF constraint_name_to_drop IS NOT NULL THEN
        EXECUTE 'ALTER TABLE public.friend_requests DROP CONSTRAINT ' || constraint_name_to_drop;
      END IF;
    END;
  END IF;
  
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints tc
    JOIN information_schema.key_column_usage kcu 
      ON tc.constraint_name = kcu.constraint_name
    WHERE tc.table_schema = 'public' 
    AND tc.table_name = 'friend_requests'
    AND tc.constraint_type = 'FOREIGN KEY'
    AND kcu.column_name = 'receiver_id'
    AND tc.constraint_name != 'friend_requests_receiver_id_fkey'
  ) THEN
    -- Get the constraint name and drop it
    DECLARE
      constraint_name_to_drop text;
    BEGIN
      SELECT tc.constraint_name INTO constraint_name_to_drop
      FROM information_schema.table_constraints tc
      JOIN information_schema.key_column_usage kcu 
        ON tc.constraint_name = kcu.constraint_name
      WHERE tc.table_schema = 'public' 
      AND tc.table_name = 'friend_requests'
      AND tc.constraint_type = 'FOREIGN KEY'
      AND kcu.column_name = 'receiver_id'
      AND tc.constraint_name != 'friend_requests_receiver_id_fkey'
      LIMIT 1;
      
      IF constraint_name_to_drop IS NOT NULL THEN
        EXECUTE 'ALTER TABLE public.friend_requests DROP CONSTRAINT ' || constraint_name_to_drop;
      END IF;
    END;
  END IF;
END $$;

-- 3) Create the foreign key constraints with the exact names PostgREST expects
ALTER TABLE public.friend_requests
  ADD CONSTRAINT friend_requests_sender_id_fkey
  FOREIGN KEY (sender_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

ALTER TABLE public.friend_requests
  ADD CONSTRAINT friend_requests_receiver_id_fkey
  FOREIGN KEY (receiver_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

-- 4) Reload PostgREST schema cache so the REST API recognizes the new relationships
NOTIFY pgrst, 'reload schema';

-- 5) Verify the constraints were created successfully
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE table_schema = 'public' 
    AND table_name = 'friend_requests'
    AND constraint_name = 'friend_requests_sender_id_fkey'
  ) THEN
    RAISE NOTICE '✅ friend_requests_sender_id_fkey constraint created successfully';
  ELSE
    RAISE EXCEPTION '❌ Failed to create friend_requests_sender_id_fkey constraint';
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE table_schema = 'public' 
    AND table_name = 'friend_requests'
    AND constraint_name = 'friend_requests_receiver_id_fkey'
  ) THEN
    RAISE NOTICE '✅ friend_requests_receiver_id_fkey constraint created successfully';
  ELSE
    RAISE EXCEPTION '❌ Failed to create friend_requests_receiver_id_fkey constraint';
  END IF;
  
  RAISE NOTICE '🚀 Foreign key constraints fixed! PostgREST can now embed profiles in friend_requests queries.';
END $$;