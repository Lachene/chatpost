/*
# Enhanced Real-Time Chat and Calling System

This migration creates a comprehensive chat and calling system like WhatsApp/Instagram:
1. Real-time messaging with typing indicators
2. Message status (sent, delivered, read)
3. Voice and video calling with WebRTC
4. Online status tracking
5. Message reactions and replies
6. File sharing capabilities
7. Call history and duration tracking
*/

-- Enhanced messages table with all WhatsApp-like features
DROP TABLE IF EXISTS public.messages CASCADE;
CREATE TABLE public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  receiver_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  content text,
  message_type text DEFAULT 'text' CHECK (message_type IN ('text', 'image', 'file', 'voice', 'video', 'location')),
  file_url text,
  file_name text,
  file_size bigint,
  reply_to_id uuid REFERENCES public.messages(id) ON DELETE SET NULL,
  status text DEFAULT 'sent' CHECK (status IN ('sent', 'delivered', 'read')),
  delivered_at timestamptz,
  read_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CHECK (sender_id != receiver_id),
  CHECK (content IS NOT NULL OR file_url IS NOT NULL)
);

-- Enhanced calls table with WebRTC support
DROP TABLE IF EXISTS public.calls CASCADE;
CREATE TABLE public.calls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  caller_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  receiver_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  call_type text DEFAULT 'voice' CHECK (call_type IN ('voice', 'video')),
  status text DEFAULT 'initiated' CHECK (status IN ('initiated', 'ringing', 'answered', 'missed', 'ended', 'declined', 'busy')),
  duration_seconds integer DEFAULT 0,
  started_at timestamptz DEFAULT now(),
  answered_at timestamptz,
  ended_at timestamptz,
  end_reason text CHECK (end_reason IN ('completed', 'missed', 'declined', 'busy', 'failed', 'network_error')),
  CHECK (caller_id != receiver_id)
);

-- Message reactions table
CREATE TABLE IF NOT EXISTS public.message_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid REFERENCES public.messages(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  reaction text NOT NULL CHECK (reaction IN ('❤️', '😂', '😮', '😢', '😡', '👍', '👎')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(message_id, user_id)
);

-- Typing indicators table
CREATE TABLE IF NOT EXISTS public.typing_indicators (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  chat_with_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  is_typing boolean DEFAULT true,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, chat_with_id),
  CHECK (user_id != chat_with_id)
);

-- Online status table
CREATE TABLE IF NOT EXISTS public.user_status (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  is_online boolean DEFAULT false,
  last_seen timestamptz DEFAULT now(),
  status_message text DEFAULT 'Available',
  updated_at timestamptz DEFAULT now()
);

-- Chat rooms for group functionality (future)
CREATE TABLE IF NOT EXISTS public.chat_rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  created_by uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  is_group boolean DEFAULT false,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.calls ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.message_reactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.typing_indicators ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_status ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_rooms ENABLE ROW LEVEL SECURITY;

-- Messages policies - only friends can message each other
CREATE POLICY "Users can read their messages"
  ON public.messages FOR SELECT
  TO authenticated
  USING (
    auth.uid() = sender_id OR auth.uid() = receiver_id
  );

CREATE POLICY "Friends can send messages"
  ON public.messages FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = sender_id AND
    EXISTS (
      SELECT 1 FROM public.friend_requests
      WHERE ((sender_id = auth.uid() AND receiver_id = messages.receiver_id) OR
             (receiver_id = auth.uid() AND sender_id = messages.receiver_id))
      AND status = 'accepted'
    )
  );

CREATE POLICY "Users can update message status"
  ON public.messages FOR UPDATE
  TO authenticated
  USING (auth.uid() = receiver_id OR auth.uid() = sender_id)
  WITH CHECK (auth.uid() = receiver_id OR auth.uid() = sender_id);

-- Calls policies
CREATE POLICY "Users can read their calls"
  ON public.calls FOR SELECT
  TO authenticated
  USING (
    auth.uid() = caller_id OR auth.uid() = receiver_id
  );

CREATE POLICY "Friends can initiate calls"
  ON public.calls FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = caller_id AND
    EXISTS (
      SELECT 1 FROM public.friend_requests
      WHERE ((sender_id = auth.uid() AND receiver_id = calls.receiver_id) OR
             (receiver_id = auth.uid() AND sender_id = calls.receiver_id))
      AND status = 'accepted'
    )
  );

CREATE POLICY "Users can update their calls"
  ON public.calls FOR UPDATE
  TO authenticated
  USING (auth.uid() = caller_id OR auth.uid() = receiver_id)
  WITH CHECK (auth.uid() = caller_id OR auth.uid() = receiver_id);

-- Message reactions policies
CREATE POLICY "Users can read message reactions"
  ON public.message_reactions FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.messages
      WHERE messages.id = message_reactions.message_id
      AND (messages.sender_id = auth.uid() OR messages.receiver_id = auth.uid())
    )
  );

CREATE POLICY "Users can add reactions"
  ON public.message_reactions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own reactions"
  ON public.message_reactions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own reactions"
  ON public.message_reactions FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Typing indicators policies
CREATE POLICY "Users can read typing indicators"
  ON public.typing_indicators FOR SELECT
  TO authenticated
  USING (auth.uid() = chat_with_id);

CREATE POLICY "Users can manage own typing indicators"
  ON public.typing_indicators FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- User status policies
CREATE POLICY "Users can read all user status"
  ON public.user_status FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage own status"
  ON public.user_status FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Functions for real-time features
CREATE OR REPLACE FUNCTION public.update_message_status()
RETURNS TRIGGER AS $$
BEGIN
  -- Auto-mark as delivered when message is created
  IF TG_OP = 'INSERT' THEN
    NEW.delivered_at = now();
    NEW.status = 'delivered';
  END IF;
  
  -- Update timestamp on status change
  IF TG_OP = 'UPDATE' AND OLD.status != NEW.status THEN
    NEW.updated_at = now();
    
    IF NEW.status = 'delivered' AND NEW.delivered_at IS NULL THEN
      NEW.delivered_at = now();
    ELSIF NEW.status = 'read' AND NEW.read_at IS NULL THEN
      NEW.read_at = now();
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.update_user_last_seen()
RETURNS TRIGGER AS $$
BEGIN
  -- Update last seen when user comes online
  IF NEW.is_online = true THEN
    NEW.updated_at = now();
  ELSE
    NEW.last_seen = now();
    NEW.updated_at = now();
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.cleanup_typing_indicators()
RETURNS TRIGGER AS $$
BEGIN
  -- Auto-cleanup old typing indicators (older than 10 seconds)
  DELETE FROM public.typing_indicators 
  WHERE updated_at < now() - interval '10 seconds';
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create triggers
CREATE TRIGGER update_message_status_trigger
  BEFORE INSERT OR UPDATE ON public.messages
  FOR EACH ROW EXECUTE FUNCTION public.update_message_status();

CREATE TRIGGER update_user_last_seen_trigger
  BEFORE UPDATE ON public.user_status
  FOR EACH ROW EXECUTE FUNCTION public.update_user_last_seen();

CREATE TRIGGER cleanup_typing_indicators_trigger
  AFTER INSERT OR UPDATE ON public.typing_indicators
  FOR EACH ROW EXECUTE FUNCTION public.cleanup_typing_indicators();

-- Create indexes for optimal performance
CREATE INDEX idx_messages_sender_receiver ON public.messages(sender_id, receiver_id);
CREATE INDEX idx_messages_receiver_sender ON public.messages(receiver_id, sender_id);
CREATE INDEX idx_messages_created_at ON public.messages(created_at DESC);
CREATE INDEX idx_messages_status ON public.messages(status);
CREATE INDEX idx_messages_reply_to ON public.messages(reply_to_id) WHERE reply_to_id IS NOT NULL;

CREATE INDEX idx_calls_participants ON public.calls(caller_id, receiver_id);
CREATE INDEX idx_calls_status ON public.calls(status);
CREATE INDEX idx_calls_started_at ON public.calls(started_at DESC);

CREATE INDEX idx_message_reactions_message ON public.message_reactions(message_id);
CREATE INDEX idx_typing_indicators_chat ON public.typing_indicators(user_id, chat_with_id);
CREATE INDEX idx_typing_indicators_updated ON public.typing_indicators(updated_at);
CREATE INDEX idx_user_status_online ON public.user_status(is_online);
CREATE INDEX idx_user_status_last_seen ON public.user_status(last_seen DESC);

-- Grant permissions
GRANT ALL ON public.messages TO authenticated;
GRANT ALL ON public.calls TO authenticated;
GRANT ALL ON public.message_reactions TO authenticated;
GRANT ALL ON public.typing_indicators TO authenticated;
GRANT ALL ON public.user_status TO authenticated;
GRANT ALL ON public.chat_rooms TO authenticated;

-- Create initial user status for existing users
INSERT INTO public.user_status (user_id, is_online, last_seen, status_message)
SELECT id, false, now(), 'Available'
FROM auth.users
ON CONFLICT (user_id) DO NOTHING;

-- Function to get chat messages between two users
CREATE OR REPLACE FUNCTION public.get_chat_messages(other_user_id uuid, limit_count integer DEFAULT 50)
RETURNS TABLE (
  id uuid,
  sender_id uuid,
  receiver_id uuid,
  content text,
  message_type text,
  file_url text,
  file_name text,
  reply_to_id uuid,
  status text,
  created_at timestamptz,
  sender_name text,
  sender_avatar text,
  reply_to_content text
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    m.id,
    m.sender_id,
    m.receiver_id,
    m.content,
    m.message_type,
    m.file_url,
    m.file_name,
    m.reply_to_id,
    m.status,
    m.created_at,
    p.full_name as sender_name,
    p.avatar_url as sender_avatar,
    rm.content as reply_to_content
  FROM public.messages m
  LEFT JOIN public.profiles p ON p.id = m.sender_id
  LEFT JOIN public.messages rm ON rm.id = m.reply_to_id
  WHERE 
    (m.sender_id = auth.uid() AND m.receiver_id = other_user_id) OR
    (m.sender_id = other_user_id AND m.receiver_id = auth.uid())
  ORDER BY m.created_at DESC
  LIMIT limit_count;
END;
$$;

-- Function to mark messages as read
CREATE OR REPLACE FUNCTION public.mark_messages_as_read(other_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.messages
  SET status = 'read', read_at = now()
  WHERE receiver_id = auth.uid() 
    AND sender_id = other_user_id 
    AND status != 'read';
END;
$$;

-- Function to update typing status
CREATE OR REPLACE FUNCTION public.update_typing_status(other_user_id uuid, typing boolean)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF typing THEN
    INSERT INTO public.typing_indicators (user_id, chat_with_id, is_typing, updated_at)
    VALUES (auth.uid(), other_user_id, true, now())
    ON CONFLICT (user_id, chat_with_id) 
    DO UPDATE SET is_typing = true, updated_at = now();
  ELSE
    DELETE FROM public.typing_indicators 
    WHERE user_id = auth.uid() AND chat_with_id = other_user_id;
  END IF;
END;
$$;

-- Function to update online status
CREATE OR REPLACE FUNCTION public.update_online_status(online boolean)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.user_status (user_id, is_online, updated_at)
  VALUES (auth.uid(), online, now())
  ON CONFLICT (user_id) 
  DO UPDATE SET is_online = online, updated_at = now();
END;
$$;

-- Test that everything is working
DO $$
BEGIN
  RAISE NOTICE '✅ Enhanced chat system created successfully!';
  RAISE NOTICE '💬 Real-time messaging with status tracking';
  RAISE NOTICE '📞 Voice and video calling support';
  RAISE NOTICE '👀 Typing indicators and online status';
  RAISE NOTICE '❤️ Message reactions and replies';
  RAISE NOTICE '📁 File sharing capabilities';
  RAISE NOTICE '🚀 WhatsApp-style chat experience ready!';
END $$;