/*
# Add Social Features: Friend Requests and Enhanced Profiles

1. New Tables
   - `friend_requests` - Friend request system
     - `id` (uuid, primary key)
     - `sender_id` (uuid, references auth.users)
     - `receiver_id` (uuid, references auth.users)
     - `status` (enum: pending, accepted, rejected)
     - `created_at` (timestamp)
     - `updated_at` (timestamp)

2. Updates to existing tables
   - Add `friends_count` to profiles table
   - Ensure follows table exists for follow system

3. Security
   - Enable RLS on all new tables
   - Users can manage their own friend requests
   - Proper policies for social interactions

4. Features
   - Send/accept/reject friend requests
   - Follow/unfollow users
   - View user profiles
   - Friend and follower counts
*/

-- Add friends_count to profiles table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'friends_count'
  ) THEN
    ALTER TABLE profiles ADD COLUMN friends_count integer DEFAULT 0;
  END IF;
END $$;

-- Create follows table if it doesn't exist
CREATE TABLE IF NOT EXISTS follows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  following_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(follower_id, following_id),
  CHECK (follower_id != following_id)
);

-- Create friend_requests table
CREATE TABLE IF NOT EXISTS friend_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  receiver_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(sender_id, receiver_id),
  CHECK (sender_id != receiver_id)
);

-- Enable RLS on new tables
ALTER TABLE follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE friend_requests ENABLE ROW LEVEL SECURITY;

-- Follows policies
CREATE POLICY "Follows are publicly readable"
  ON follows FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage own follows"
  ON follows FOR ALL
  TO authenticated
  USING (auth.uid() = follower_id)
  WITH CHECK (auth.uid() = follower_id);

-- Friend requests policies
CREATE POLICY "Users can read their friend requests"
  ON friend_requests FOR SELECT
  TO authenticated
  USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can send friend requests"
  ON friend_requests FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = sender_id);

CREATE POLICY "Users can update received friend requests"
  ON friend_requests FOR UPDATE
  TO authenticated
  USING (auth.uid() = receiver_id)
  WITH CHECK (auth.uid() = receiver_id);

CREATE POLICY "Users can delete their sent friend requests"
  ON friend_requests FOR DELETE
  TO authenticated
  USING (auth.uid() = sender_id);

-- Function to update follow counts
CREATE OR REPLACE FUNCTION update_follow_counts()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE profiles SET following_count = following_count + 1 WHERE id = NEW.follower_id;
    UPDATE profiles SET followers_count = followers_count + 1 WHERE id = NEW.following_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE profiles SET following_count = GREATEST(following_count - 1, 0) WHERE id = OLD.follower_id;
    UPDATE profiles SET followers_count = GREATEST(followers_count - 1, 0) WHERE id = OLD.following_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to update friends count
CREATE OR REPLACE FUNCTION update_friends_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' AND NEW.status = 'accepted' THEN
    -- Increment friends count for both users
    UPDATE profiles SET friends_count = friends_count + 1 WHERE id = NEW.sender_id;
    UPDATE profiles SET friends_count = friends_count + 1 WHERE id = NEW.receiver_id;
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    IF OLD.status != 'accepted' AND NEW.status = 'accepted' THEN
      -- Friend request accepted
      UPDATE profiles SET friends_count = friends_count + 1 WHERE id = NEW.sender_id;
      UPDATE profiles SET friends_count = friends_count + 1 WHERE id = NEW.receiver_id;
    ELSIF OLD.status = 'accepted' AND NEW.status != 'accepted' THEN
      -- Friendship ended
      UPDATE profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = NEW.sender_id;
      UPDATE profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = NEW.receiver_id;
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' AND OLD.status = 'accepted' THEN
    -- Friendship deleted
    UPDATE profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = OLD.sender_id;
    UPDATE profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = OLD.receiver_id;
    RETURN OLD;
  END IF;
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to update updated_at timestamp for friend requests
CREATE OR REPLACE FUNCTION update_friend_request_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for count updates
DROP TRIGGER IF EXISTS update_follow_counts_trigger ON follows;
CREATE TRIGGER update_follow_counts_trigger
  AFTER INSERT OR DELETE ON follows
  FOR EACH ROW EXECUTE FUNCTION update_follow_counts();

DROP TRIGGER IF EXISTS update_friends_count_trigger ON friend_requests;
CREATE TRIGGER update_friends_count_trigger
  AFTER INSERT OR UPDATE OR DELETE ON friend_requests
  FOR EACH ROW EXECUTE FUNCTION update_friends_count();

-- Trigger for friend_requests updated_at
DROP TRIGGER IF EXISTS update_friend_requests_updated_at ON friend_requests;
CREATE TRIGGER update_friend_requests_updated_at
  BEFORE UPDATE ON friend_requests
  FOR EACH ROW EXECUTE FUNCTION update_friend_request_updated_at();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_follows_follower_id ON follows(follower_id);
CREATE INDEX IF NOT EXISTS idx_follows_following_id ON follows(following_id);
CREATE INDEX IF NOT EXISTS idx_friend_requests_sender_id ON friend_requests(sender_id);
CREATE INDEX IF NOT EXISTS idx_friend_requests_receiver_id ON friend_requests(receiver_id);
CREATE INDEX IF NOT EXISTS idx_friend_requests_status ON friend_requests(status);

-- Fix any existing friends count discrepancies
UPDATE profiles 
SET friends_count = (
  SELECT COUNT(*) 
  FROM friend_requests 
  WHERE (friend_requests.sender_id = profiles.id OR friend_requests.receiver_id = profiles.id)
  AND friend_requests.status = 'accepted'
);

-- Fix any existing follow count discrepancies
UPDATE profiles 
SET followers_count = (
  SELECT COUNT(*) 
  FROM follows 
  WHERE follows.following_id = profiles.id
);

UPDATE profiles 
SET following_count = (
  SELECT COUNT(*) 
  FROM follows 
  WHERE follows.follower_id = profiles.id
);