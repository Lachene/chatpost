/*
# Add Post Editing Feature

This migration enables users to edit their posts within 7 days of creation.

1. Features
   - Users can edit their posts within 7 days
   - Edit both content and image URL
   - Track when posts were last updated
   - Show "edited" indicator on modified posts

2. Security
   - Users can only edit their own posts
   - 7-day time limit enforced in the application
   - Proper RLS policies maintained

3. Database Changes
   - Ensure updated_at column exists and is properly updated
   - Add trigger to automatically update updated_at timestamp
*/

-- Ensure updated_at column exists (it should already exist)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'posts' AND column_name = 'updated_at'
  ) THEN
    ALTER TABLE posts ADD COLUMN updated_at timestamptz DEFAULT now();
  END IF;
END $$;

-- Ensure the updated_at trigger function exists and works properly
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Recreate the trigger to ensure it works
DROP TRIGGER IF EXISTS update_posts_updated_at ON posts;
CREATE TRIGGER update_posts_updated_at
  BEFORE UPDATE ON posts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Ensure posts have proper policies for editing
-- Users should be able to update their own posts (this should already exist)
DO $$
BEGIN
  -- Check if the update policy exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'posts' 
    AND policyname = 'Users can update own posts'
  ) THEN
    CREATE POLICY "Users can update own posts"
      ON posts FOR UPDATE
      TO authenticated
      USING (auth.uid() = user_id)
      WITH CHECK (auth.uid() = user_id);
  END IF;
END $$;

-- Test that the trigger is working
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'update_updated_at_column') THEN
    RAISE NOTICE 'Post editing trigger function created successfully';
  ELSE
    RAISE EXCEPTION 'Post editing trigger function was not created';
  END IF;
END $$;