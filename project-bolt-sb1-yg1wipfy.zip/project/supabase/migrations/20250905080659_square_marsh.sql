/*
# Fix Database Error During User Registration

This SQL fixes the 500 error that occurs when new users try to register.
The issue is with the trigger function that creates profiles for new users.

Run this in Supabase SQL Editor as a NEW query.
*/

-- First, let's drop the existing trigger to prevent conflicts
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Drop the existing function
DROP FUNCTION IF EXISTS handle_new_user();

-- Create a more robust function that won't cause auth failures
CREATE OR REPLACE FUNCTION handle_new_user() 
RETURNS TRIGGER AS $$
DECLARE
  username_attempt text;
  attempt_count integer := 0;
  max_attempts integer := 3;
  profile_created boolean := false;
BEGIN
  -- Log the attempt
  RAISE LOG 'Creating profile for new user: %', NEW.id;
  
  -- Generate initial username
  username_attempt := COALESCE(
    NEW.raw_user_meta_data->>'username',
    'user_' || substr(replace(NEW.id::text, '-', ''), 1, 8)
  );
  
  -- Clean username (lowercase, alphanumeric and underscore only)
  username_attempt := lower(regexp_replace(username_attempt, '[^a-zA-Z0-9_]', '', 'g'));
  
  -- Ensure username is not empty and has minimum length
  IF username_attempt = '' OR length(username_attempt) < 3 THEN
    username_attempt := 'user_' || substr(replace(NEW.id::text, '-', ''), 1, 8);
  END IF;
  
  -- Try to create profile with retry logic
  WHILE attempt_count < max_attempts AND NOT profile_created LOOP
    BEGIN
      -- Attempt to insert the profile
      INSERT INTO public.profiles (id, username, full_name, bio, avatar_url, followers_count, following_count, posts_count, created_at)
      VALUES (
        NEW.id,
        username_attempt,
        COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
        '',
        NULL,
        0,
        0,
        0,
        now()
      );
      
      profile_created := true;
      RAISE LOG 'Profile created successfully for user: % with username: %', NEW.id, username_attempt;
      
    EXCEPTION 
      WHEN unique_violation THEN
        -- Username already exists, try with a suffix
        attempt_count := attempt_count + 1;
        username_attempt := COALESCE(
          NEW.raw_user_meta_data->>'username',
          'user_' || substr(replace(NEW.id::text, '-', ''), 1, 8)
        ) || '_' || attempt_count;
        
        -- Clean the new username attempt
        username_attempt := lower(regexp_replace(username_attempt, '[^a-zA-Z0-9_]', '', 'g'));
        
        RAISE LOG 'Username conflict, trying: %', username_attempt;
        
      WHEN OTHERS THEN
        -- Log the error but don't fail the user creation
        RAISE WARNING 'Error creating profile for user % (attempt %): %', NEW.id, attempt_count + 1, SQLERRM;
        attempt_count := attempt_count + 1;
        
        -- Try with a timestamp-based username for the next attempt
        username_attempt := 'user_' || substr(replace(NEW.id::text, '-', ''), 1, 8) || '_' || extract(epoch from now())::bigint;
    END;
  END LOOP;
  
  -- If we still haven't created a profile, try one final time with a guaranteed unique username
  IF NOT profile_created THEN
    BEGIN
      username_attempt := 'user_' || replace(NEW.id::text, '-', '');
      
      INSERT INTO public.profiles (id, username, full_name, bio, avatar_url, followers_count, following_count, posts_count, created_at)
      VALUES (
        NEW.id,
        username_attempt,
        COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
        '',
        NULL,
        0,
        0,
        0,
        now()
      );
      
      RAISE LOG 'Profile created with UUID-based username for user: %', NEW.id;
      
    EXCEPTION WHEN OTHERS THEN
      -- Even if profile creation fails, we must not prevent user creation
      RAISE WARNING 'Final attempt to create profile failed for user %: %', NEW.id, SQLERRM;
    END;
  END IF;
  
  -- Always return NEW to allow user creation to proceed
  RETURN NEW;
  
EXCEPTION WHEN OTHERS THEN
  -- Catch any unexpected errors and log them, but don't prevent user creation
  RAISE WARNING 'Unexpected error in handle_new_user for user %: %', NEW.id, SQLERRM;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate the trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Ensure the profiles table exists with correct structure
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  username text UNIQUE NOT NULL,
  full_name text NOT NULL DEFAULT '',
  bio text DEFAULT '',
  avatar_url text,
  followers_count integer DEFAULT 0,
  following_count integer DEFAULT 0,
  posts_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Ensure RLS is enabled
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Recreate policies if they don't exist
DO $$ 
BEGIN
  -- Drop existing policies
  DROP POLICY IF EXISTS "Profiles are publicly readable" ON public.profiles;
  DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
  DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
  
  -- Recreate policies
  CREATE POLICY "Profiles are publicly readable"
    ON public.profiles FOR SELECT
    TO authenticated
    USING (true);

  CREATE POLICY "Users can update own profile"
    ON public.profiles FOR UPDATE
    TO authenticated
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

  CREATE POLICY "Users can insert own profile"
    ON public.profiles FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = id);
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_profiles_username ON public.profiles(username);
CREATE INDEX IF NOT EXISTS idx_profiles_id ON public.profiles(id);

-- Test the function by checking if it exists
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'handle_new_user') THEN
    RAISE NOTICE 'handle_new_user function created successfully';
  ELSE
    RAISE EXCEPTION 'handle_new_user function was not created';
  END IF;
END $$;