/*
# Fix Posts Count and Visibility Issues

This migration fixes:
1. Posts not showing up after creation
2. Posts count not updating properly
3. Ensures proper triggers are working

*/

-- First, let's check and fix the posts count trigger
DROP TRIGGER IF EXISTS update_posts_count_trigger ON posts;
DROP FUNCTION IF EXISTS update_posts_count();

-- Recreate the posts count function
CREATE OR REPLACE FUNCTION update_posts_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Increment posts count when a new post is created
    UPDATE profiles 
    SET posts_count = posts_count + 1 
    WHERE id = NEW.user_id;
    
    RAISE LOG 'Incremented posts count for user: %', NEW.user_id;
    RETURN NEW;
    
  ELSIF TG_OP = 'DELETE' THEN
    -- Decrement posts count when a post is deleted
    UPDATE profiles 
    SET posts_count = GREATEST(posts_count - 1, 0)
    WHERE id = OLD.user_id;
    
    RAISE LOG 'Decremented posts count for user: %', OLD.user_id;
    RETURN OLD;
  END IF;
  
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate the trigger
CREATE TRIGGER update_posts_count_trigger
  AFTER INSERT OR DELETE ON posts
  FOR EACH ROW EXECUTE FUNCTION update_posts_count();

-- Fix any existing posts count discrepancies
UPDATE profiles 
SET posts_count = (
  SELECT COUNT(*) 
  FROM posts 
  WHERE posts.user_id = profiles.id
);

-- Ensure posts table has proper structure
ALTER TABLE posts 
  ALTER COLUMN user_id SET NOT NULL,
  ALTER COLUMN content SET NOT NULL,
  ALTER COLUMN created_at SET DEFAULT now(),
  ALTER COLUMN updated_at SET DEFAULT now();

-- Ensure likes count trigger is working
DROP TRIGGER IF EXISTS update_likes_count_trigger ON likes;
DROP FUNCTION IF EXISTS update_likes_count();

CREATE OR REPLACE FUNCTION update_likes_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE posts SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE posts SET likes_count = GREATEST(likes_count - 1, 0) WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER update_likes_count_trigger
  AFTER INSERT OR DELETE ON likes
  FOR EACH ROW EXECUTE FUNCTION update_likes_count();

-- Ensure comments count trigger is working
DROP TRIGGER IF EXISTS update_comments_count_trigger ON comments;
DROP FUNCTION IF EXISTS update_comments_count();

CREATE OR REPLACE FUNCTION update_comments_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE posts SET comments_count = comments_count + 1 WHERE id = NEW.post_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE posts SET comments_count = GREATEST(comments_count - 1, 0) WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER update_comments_count_trigger
  AFTER INSERT OR DELETE ON comments
  FOR EACH ROW EXECUTE FUNCTION update_comments_count();

-- Test that triggers are working
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'update_posts_count') THEN
    RAISE NOTICE 'Posts count trigger function created successfully';
  ELSE
    RAISE EXCEPTION 'Posts count trigger function was not created';
  END IF;
END $$;