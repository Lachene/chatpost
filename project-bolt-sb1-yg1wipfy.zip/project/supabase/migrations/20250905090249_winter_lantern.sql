/*
# Fix Follow System and Social Features

This migration fixes:
1. Follow system not updating counts properly
2. Account creation date display issues
3. Friend request visibility problems
4. Real-time updates for social features

*/

-- First, let's ensure all tables exist and have proper structure
CREATE TABLE IF NOT EXISTS public.follows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  following_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(follower_id, following_id),
  CHECK (follower_id != following_id)
);

CREATE TABLE IF NOT EXISTS public.friend_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  receiver_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(sender_id, receiver_id),
  CHECK (sender_id != receiver_id)
);

-- Ensure profiles table has all required columns
DO $$
BEGIN
  -- Add friends_count if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'friends_count'
  ) THEN
    ALTER TABLE public.profiles ADD COLUMN friends_count integer DEFAULT 0;
  END IF;
  
  -- Ensure all count columns exist and have proper defaults
  UPDATE public.profiles SET 
    followers_count = COALESCE(followers_count, 0),
    following_count = COALESCE(following_count, 0),
    posts_count = COALESCE(posts_count, 0),
    friends_count = COALESCE(friends_count, 0)
  WHERE followers_count IS NULL OR following_count IS NULL OR posts_count IS NULL OR friends_count IS NULL;
END $$;

-- Enable RLS on all tables
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.friend_requests ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to recreate them properly
DROP POLICY IF EXISTS "Follows are publicly readable" ON public.follows;
DROP POLICY IF EXISTS "Users can manage own follows" ON public.follows;
DROP POLICY IF EXISTS "Users can read their friend requests" ON public.friend_requests;
DROP POLICY IF EXISTS "Users can send friend requests" ON public.friend_requests;
DROP POLICY IF EXISTS "Users can update received friend requests" ON public.friend_requests;
DROP POLICY IF EXISTS "Users can delete their sent friend requests" ON public.friend_requests;

-- Recreate policies with proper permissions
CREATE POLICY "Follows are publicly readable"
  ON public.follows FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own follows"
  ON public.follows FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = follower_id);

CREATE POLICY "Users can delete own follows"
  ON public.follows FOR DELETE
  TO authenticated
  USING (auth.uid() = follower_id);

CREATE POLICY "Users can read their friend requests"
  ON public.friend_requests FOR SELECT
  TO authenticated
  USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can send friend requests"
  ON public.friend_requests FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = sender_id);

CREATE POLICY "Users can update received friend requests"
  ON public.friend_requests FOR UPDATE
  TO authenticated
  USING (auth.uid() = receiver_id)
  WITH CHECK (auth.uid() = receiver_id);

CREATE POLICY "Users can delete their sent friend requests"
  ON public.friend_requests FOR DELETE
  TO authenticated
  USING (auth.uid() = sender_id);

-- Drop existing triggers and functions to recreate them
DROP TRIGGER IF EXISTS update_follow_counts_trigger ON public.follows;
DROP TRIGGER IF EXISTS update_friends_count_trigger ON public.friend_requests;
DROP TRIGGER IF EXISTS update_friend_requests_updated_at ON public.friend_requests;

DROP FUNCTION IF EXISTS public.update_follow_counts();
DROP FUNCTION IF EXISTS public.update_friends_count();
DROP FUNCTION IF EXISTS public.update_friend_request_updated_at();

-- Recreate functions with better error handling
CREATE OR REPLACE FUNCTION public.update_follow_counts()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Increment following count for follower
    UPDATE public.profiles 
    SET following_count = GREATEST(following_count + 1, 0)
    WHERE id = NEW.follower_id;
    
    -- Increment followers count for the person being followed
    UPDATE public.profiles 
    SET followers_count = GREATEST(followers_count + 1, 0)
    WHERE id = NEW.following_id;
    
    RAISE LOG 'Follow added: % following %', NEW.follower_id, NEW.following_id;
    RETURN NEW;
    
  ELSIF TG_OP = 'DELETE' THEN
    -- Decrement following count for follower
    UPDATE public.profiles 
    SET following_count = GREATEST(following_count - 1, 0)
    WHERE id = OLD.follower_id;
    
    -- Decrement followers count for the person being unfollowed
    UPDATE public.profiles 
    SET followers_count = GREATEST(followers_count - 1, 0)
    WHERE id = OLD.following_id;
    
    RAISE LOG 'Follow removed: % unfollowed %', OLD.follower_id, OLD.following_id;
    RETURN OLD;
  END IF;
  
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.update_friends_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' AND NEW.status = 'accepted' THEN
    -- Increment friends count for both users
    UPDATE public.profiles SET friends_count = GREATEST(friends_count + 1, 0) WHERE id = NEW.sender_id;
    UPDATE public.profiles SET friends_count = GREATEST(friends_count + 1, 0) WHERE id = NEW.receiver_id;
    RAISE LOG 'Friendship created: % and %', NEW.sender_id, NEW.receiver_id;
    RETURN NEW;
    
  ELSIF TG_OP = 'UPDATE' THEN
    IF OLD.status != 'accepted' AND NEW.status = 'accepted' THEN
      -- Friend request accepted
      UPDATE public.profiles SET friends_count = GREATEST(friends_count + 1, 0) WHERE id = NEW.sender_id;
      UPDATE public.profiles SET friends_count = GREATEST(friends_count + 1, 0) WHERE id = NEW.receiver_id;
      RAISE LOG 'Friend request accepted: % and %', NEW.sender_id, NEW.receiver_id;
    ELSIF OLD.status = 'accepted' AND NEW.status != 'accepted' THEN
      -- Friendship ended
      UPDATE public.profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = NEW.sender_id;
      UPDATE public.profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = NEW.receiver_id;
      RAISE LOG 'Friendship ended: % and %', NEW.sender_id, NEW.receiver_id;
    END IF;
    RETURN NEW;
    
  ELSIF TG_OP = 'DELETE' AND OLD.status = 'accepted' THEN
    -- Friendship deleted
    UPDATE public.profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = OLD.sender_id;
    UPDATE public.profiles SET friends_count = GREATEST(friends_count - 1, 0) WHERE id = OLD.receiver_id;
    RAISE LOG 'Friendship deleted: % and %', OLD.sender_id, OLD.receiver_id;
    RETURN OLD;
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.update_friend_request_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Recreate triggers
CREATE TRIGGER update_follow_counts_trigger
  AFTER INSERT OR DELETE ON public.follows
  FOR EACH ROW EXECUTE FUNCTION public.update_follow_counts();

CREATE TRIGGER update_friends_count_trigger
  AFTER INSERT OR UPDATE OR DELETE ON public.friend_requests
  FOR EACH ROW EXECUTE FUNCTION public.update_friends_count();

CREATE TRIGGER update_friend_requests_updated_at
  BEFORE UPDATE ON public.friend_requests
  FOR EACH ROW EXECUTE FUNCTION public.update_friend_request_updated_at();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_follows_follower_id ON public.follows(follower_id);
CREATE INDEX IF NOT EXISTS idx_follows_following_id ON public.follows(following_id);
CREATE INDEX IF NOT EXISTS idx_friend_requests_sender_id ON public.friend_requests(sender_id);
CREATE INDEX IF NOT EXISTS idx_friend_requests_receiver_id ON public.friend_requests(receiver_id);
CREATE INDEX IF NOT EXISTS idx_friend_requests_status ON public.friend_requests(status);

-- Fix any existing count discrepancies
UPDATE public.profiles 
SET followers_count = COALESCE((
  SELECT COUNT(*) 
  FROM public.follows 
  WHERE follows.following_id = profiles.id
), 0);

UPDATE public.profiles 
SET following_count = COALESCE((
  SELECT COUNT(*) 
  FROM public.follows 
  WHERE follows.follower_id = profiles.id
), 0);

UPDATE public.profiles 
SET friends_count = COALESCE((
  SELECT COUNT(*) 
  FROM public.friend_requests 
  WHERE (friend_requests.sender_id = profiles.id OR friend_requests.receiver_id = profiles.id)
  AND friend_requests.status = 'accepted'
), 0);

-- Grant proper permissions
GRANT ALL ON public.follows TO authenticated;
GRANT ALL ON public.friend_requests TO authenticated;
GRANT USAGE ON SCHEMA public TO authenticated;

-- Refresh the schema cache
NOTIFY pgrst, 'reload schema';

-- Test that everything is working
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'follows' AND table_schema = 'public') THEN
    RAISE NOTICE 'follows table exists and is accessible';
  ELSE
    RAISE EXCEPTION 'follows table is not accessible';
  END IF;
  
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'friend_requests' AND table_schema = 'public') THEN
    RAISE NOTICE 'friend_requests table exists and is accessible';
  ELSE
    RAISE EXCEPTION 'friend_requests table is not accessible';
  END IF;
  
  RAISE NOTICE 'All social tables are properly configured!';
END $$;