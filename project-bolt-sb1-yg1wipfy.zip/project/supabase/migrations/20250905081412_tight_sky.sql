/*
# Fix Post Ownership and User Isolation

This migration ensures that:
1. Posts show the correct author information
2. Users can only delete their own posts
3. Proper user isolation is maintained

*/

-- Update the posts policies to ensure proper data access
DROP POLICY IF EXISTS "Posts are publicly readable" ON posts;
CREATE POLICY "Posts are publicly readable"
  ON posts FOR SELECT
  TO authenticated
  USING (true);

-- Ensure users can only delete their own posts
DROP POLICY IF EXISTS "Users can delete own posts" ON posts;
CREATE POLICY "Users can delete own posts"
  ON posts FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Ensure users can only update their own posts
DROP POLICY IF EXISTS "Users can update own posts" ON posts;
CREATE POLICY "Users can update own posts"
  ON posts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Make sure the profiles table has proper policies
DROP POLICY IF EXISTS "Profiles are publicly readable" ON profiles;
CREATE POLICY "Profiles are publicly readable"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

-- Add a function to get post with author info (for better queries)
CREATE OR REPLACE VIEW posts_with_profiles AS
SELECT 
  p.*,
  pr.username,
  pr.full_name,
  pr.avatar_url
FROM posts p
LEFT JOIN profiles pr ON p.user_id = pr.id;

-- Grant access to the view
GRANT SELECT ON posts_with_profiles TO authenticated;