/*
# Fix Post Reactions System

This migration creates a proper post reactions system so users can react to posts.

1. New Tables
   - `post_reactions` - Store reactions on posts
     - `id` (uuid, primary key)
     - `post_id` (uuid, references posts)
     - `user_id` (uuid, references auth.users)
     - `reaction` (text, emoji reaction)
     - `created_at` (timestamp)

2. Security
   - Enable RLS on post_reactions table
   - Users can read all reactions
   - Users can only add/remove their own reactions

3. Features
   - Real-time reaction updates
   - Multiple reaction types (❤️, 😂, 😮, 😢, 😡, 👍, 👎)
   - Reaction count tracking
*/

-- Create post_reactions table
CREATE TABLE IF NOT EXISTS public.post_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES public.posts(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  reaction text NOT NULL CHECK (reaction IN ('❤️', '😂', '😮', '😢', '😡', '👍', '👎')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(post_id, user_id, reaction)
);

-- Enable RLS
ALTER TABLE public.post_reactions ENABLE ROW LEVEL SECURITY;

-- Post reactions policies
CREATE POLICY "Post reactions are publicly readable"
  ON public.post_reactions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can add their own reactions"
  ON public.post_reactions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own reactions"
  ON public.post_reactions FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Add reactions_count column to posts table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'posts' AND column_name = 'reactions_count'
  ) THEN
    ALTER TABLE public.posts ADD COLUMN reactions_count integer DEFAULT 0;
  END IF;
END $$;

-- Function to update reactions count
CREATE OR REPLACE FUNCTION public.update_reactions_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.posts SET reactions_count = reactions_count + 1 WHERE id = NEW.post_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.posts SET reactions_count = GREATEST(reactions_count - 1, 0) WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for reactions count updates
DROP TRIGGER IF EXISTS update_reactions_count_trigger ON public.post_reactions;
CREATE TRIGGER update_reactions_count_trigger
  AFTER INSERT OR DELETE ON public.post_reactions
  FOR EACH ROW EXECUTE FUNCTION public.update_reactions_count();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_post_reactions_post_id ON public.post_reactions(post_id);
CREATE INDEX IF NOT EXISTS idx_post_reactions_user_id ON public.post_reactions(user_id);
CREATE INDEX IF NOT EXISTS idx_post_reactions_reaction ON public.post_reactions(reaction);

-- Grant permissions
GRANT ALL ON public.post_reactions TO authenticated;

-- Fix existing posts reactions count
UPDATE public.posts 
SET reactions_count = COALESCE((
  SELECT COUNT(*) 
  FROM public.post_reactions 
  WHERE post_reactions.post_id = posts.id
), 0);

-- Function to add reaction to post
CREATE OR REPLACE FUNCTION public.add_post_reaction(post_id_param uuid, reaction_param text)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Check if reaction already exists
  IF EXISTS (
    SELECT 1 FROM public.post_reactions 
    WHERE post_id = post_id_param 
    AND user_id = auth.uid() 
    AND reaction = reaction_param
  ) THEN
    -- Remove existing reaction
    DELETE FROM public.post_reactions 
    WHERE post_id = post_id_param 
    AND user_id = auth.uid() 
    AND reaction = reaction_param;
    
    RETURN json_build_object(
      'success', true,
      'action', 'removed',
      'message', 'Reaction removed',
      'reaction', reaction_param
    );
  ELSE
    -- Remove any other reaction from this user on this post
    DELETE FROM public.post_reactions 
    WHERE post_id = post_id_param 
    AND user_id = auth.uid();
    
    -- Add new reaction
    INSERT INTO public.post_reactions (post_id, user_id, reaction)
    VALUES (post_id_param, auth.uid(), reaction_param);
    
    RETURN json_build_object(
      'success', true,
      'action', 'added',
      'message', 'Reaction added',
      'reaction', reaction_param
    );
  END IF;
END;
$$;

-- Function to get reactions for a post
CREATE OR REPLACE FUNCTION public.get_post_reactions(post_id_param uuid)
RETURNS TABLE (
  reaction text,
  count bigint,
  user_reacted boolean
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pr.reaction,
    COUNT(*) as count,
    bool_or(pr.user_id = auth.uid()) as user_reacted
  FROM public.post_reactions pr
  WHERE pr.post_id = post_id_param
  GROUP BY pr.reaction
  ORDER BY count DESC;
END;
$$;

-- Grant permissions on functions
GRANT EXECUTE ON FUNCTION public.add_post_reaction(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_post_reactions(uuid) TO authenticated;

-- Success message
DO $$
BEGIN
  RAISE NOTICE '🎉 POST REACTIONS SYSTEM CREATED!';
  RAISE NOTICE '================================';
  RAISE NOTICE '✅ Users can now react to posts';
  RAISE NOTICE '✅ 7 different reaction types available';
  RAISE NOTICE '✅ Real-time reaction updates';
  RAISE NOTICE '✅ Reaction counts tracked automatically';
  RAISE NOTICE '';
  RAISE NOTICE '🧪 Functions Available:';
  RAISE NOTICE '   - SELECT add_post_reaction(post_id, ''❤️'');';
  RAISE NOTICE '   - SELECT get_post_reactions(post_id);';
  RAISE NOTICE '';
  RAISE NOTICE '😍 USERS CAN NOW REACT TO POSTS!';
  RAISE NOTICE '================================';
END $$;